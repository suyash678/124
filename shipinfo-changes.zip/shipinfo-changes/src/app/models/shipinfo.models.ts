export interface ShipInfoFilter {
  Column: string;
  Operator: 'equals' | 'contains' | 'startswith' | 'endswith' | 'gte' | 'lte' | 'range';
  Value: string | number | (string | number)[];
}

export interface ShipInfoSearchRequest {
  SelectedColumns: string[];
  Filters: ShipInfoFilter[];
}

export interface ColumnDef {
  label: string;
  column: string;
  category: string;
}

export interface ActiveFilter {
  def: ColumnDef;
  operator: ShipInfoFilter['Operator'];
  value: string;
  value2?: string;
}

export type VesselRow = Record<string, string | number | null>;
