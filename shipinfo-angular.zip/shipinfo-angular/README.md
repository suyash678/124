# ShipInfo Angular Frontend

Angular 17 frontend for the ShipInfo maritime intelligence platform.
Built to work directly with your existing **ShipInfo_API** (ASP.NET Core + Dapper).

## Features (aligned exactly to your API)

| Feature | Detail |
|---------|--------|
| **Column selector** | Pick up to 25 columns from `shipinfo_final` — grouped by category |
| **Filters** | Add filters per column with correct operators |
| **Operators** | `equals`, `contains`, `startswith`, `gte`, `lte`, `range` |
| **Results table** | Sortable columns, row filter, paginated (20/page) |
| **Export CSV** | Downloads selected columns for all matched rows |
| **Ship background** | Inline SVG — no external image dependency |

## Quick Start

```bash
npm install
ng serve --proxy-config proxy.conf.json
```

Open **http://localhost:4200**

Your **ShipInfo_API** must be running on port 5000.

## API Contract

```
POST /api/shipinfo/search
Content-Type: application/json

{
  "SelectedColumns": ["VesselName", "IMONumber", "FlagState"],
  "Filters": [
    { "Column": "FlagState",    "Operator": "equals",    "Value": "Panama"  },
    { "Column": "GrossTonnage", "Operator": "gte",       "Value": 50000     },
    { "Column": "VesselName",   "Operator": "contains",  "Value": "EVER"    },
    { "Column": "YearBuilt",    "Operator": "range",     "Value": [2010, 2020] }
  ]
}
```

Returns: `any[]` — plain array of rows from `shipinfo_final`.

## Project Structure

```
src/app/
├── app.component.ts              Root component
├── app.config.ts                 DI providers (HttpClient, Router, Animations)
├── app.routes.ts                 Routes: / → Home, /search → Search
│
├── models/
│   ├── shipinfo.models.ts        TypeScript mirrors of backend DTOs
│   └── columns.ts                All column definitions (label → SQL column)
│
├── services/
│   └── shipinfo.service.ts       POST /api/shipinfo/search via HttpClient
│
└── components/
    ├── navbar/                   Top nav: logo | links | user pill
    ├── ship-bg/                  Inline SVG ship hull (fixed background)
    ├── home/                     Landing page — SHIPINFO title over hull
    └── search/                   Full search workspace
        ├── search.component.ts   All state & logic
        ├── search.component.html Template
        └── search.component.css  Dark panel styling
```

## CORS

Add this to your `Program.cs` or `Startup.cs`:

```csharp
builder.Services.AddCors(options => {
    options.AddPolicy("Dev", policy =>
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyMethod()
              .AllowAnyHeader());
});
app.UseCors("Dev");
```

## Adding Columns

Open `src/app/models/columns.ts` and add entries to `ALL_COLUMNS`:

```ts
{ label: 'My New Field', column: 'MyNewColumn', category: 'Identity' }
```

The column name must match exactly what exists in `shipinfo_final`.

## Production Build

```bash
ng build --configuration production
```

Copy `dist/shipinfo-angular/browser/` to your API's `wwwroot/` folder,
or deploy to any static host.

## SSO Integration

In `navbar.component.ts`, the `@Input() userName` and `@Input() userPhoto` inputs
accept values from your MSAL / OAuth integration. Wire them from `app.component.ts`
after reading the authenticated user profile.
