// ── Exact mirror of ShipInfo_API backend DTOs ──────────────────────────────

/** Mirrors ShipInfoFilter.cs */
export interface ShipInfoFilter {
  Column: string;
  /** equals | contains | startswith | range | gte | lte */
  Operator: 'equals' | 'contains' | 'startswith' | 'range' | 'gte' | 'lte';
  Value: string | number | (string | number)[];
}

/** Mirrors ShipInfoSearchRequest.cs */
export interface ShipInfoSearchRequest {
  SelectedColumns: string[];   // max 25
  Filters: ShipInfoFilter[];
}

// ── Frontend-only types ─────────────────────────────────────────────────────

/** A column definition shown in the Column Selector panel */
export interface ColumnDef {
  label: string;       // display name shown to user
  column: string;      // SQL column name in shipinfo_final
  category: string;    // grouping for the UI
}

/** An active filter the user has configured */
export interface ActiveFilter {
  def: ColumnDef;
  operator: ShipInfoFilter['Operator'];
  value: string;       // raw user input string
  value2?: string;     // second value for 'range' operator
}

/** A row returned from shipinfo_final — dynamic, keyed by column name */
export type VesselRow = Record<string, string | number | null>;
