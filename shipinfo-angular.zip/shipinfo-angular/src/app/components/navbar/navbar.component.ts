import { Component, Input } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <nav class="nav">
      <!-- Left: company logo -->
      <button class="nav-logo" (click)="router.navigate(['/'])">
        <div class="logo-mark">
          <svg viewBox="0 0 24 24"><path d="M2 20h20v2H2zM4 14h4v6H4zm6-4h4v10h-4zm6-5h4v15h-4z"/></svg>
        </div>
        <span class="logo-text">YourCo</span>
      </button>

      <!-- Centre: nav links -->
      <div class="nav-links">
        <a class="nav-link" routerLink="/"      routerLinkActive="active"
           [routerLinkActiveOptions]="{exact:true}">Home</a>
        <a class="nav-link" routerLink="/search" routerLinkActive="active">Advanced Search</a>
      </div>

      <!-- Right: user identity (SSO) -->
      <div class="nav-right">
        <div class="user-pill">
          <div class="user-avatar">
            <ng-container *ngIf="userPhoto; else initials">
              <img [src]="userPhoto" [alt]="userName"/>
            </ng-container>
            <ng-template #initials>{{ getInitials() }}</ng-template>
          </div>
          <div class="user-info">
            <span class="user-greeting">Welcome</span>
            <span class="user-name">{{ userName }}</span>
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .nav {
      position: fixed; top: 0; left: 0; right: 0;
      height: var(--nav-h);
      background: rgba(232,232,230,0.92);
      backdrop-filter: blur(8px);
      display: flex; align-items: center;
      z-index: 100;
    }
    .nav-logo {
      display: flex; align-items: center; gap: 9px;
      padding: 0 24px; height: 100%;
      background: none; border: none; cursor: pointer;
      border-right: 1px solid rgba(0,0,0,.1);
    }
    .logo-mark {
      width: 28px; height: 28px; background: #222;
      display: flex; align-items: center; justify-content: center;
    }
    .logo-mark svg { fill: #fff; width: 14px; height: 14px; }
    .logo-text { font-size: 12px; font-weight: 700; color: #222; letter-spacing: .02em; }

    .nav-links { display: flex; height: 100%; padding-left: 12px; }
    .nav-link {
      display: flex; align-items: center;
      padding: 0 22px; height: 100%;
      font-size: 13px; font-weight: 500; color: #555;
      text-decoration: none; border: none; background: none;
      border-bottom: 3px solid transparent; border-top: 3px solid transparent;
      transition: all .15s; white-space: nowrap;
    }
    .nav-link:hover { color: #000; border-bottom-color: #ccc; }
    .nav-link.active { color: #000; font-weight: 600; border-bottom-color: #111; background: rgba(0,0,0,.05); }

    .nav-right {
      margin-left: auto; margin-right: 20px;
      display: flex; align-items: center;
    }
    .user-pill {
      display: flex; align-items: center; gap: 8px;
      padding: 5px 10px; background: none; border: none; cursor: default;
    }
    .user-avatar {
      width: 30px; height: 30px; border-radius: 50%;
      background: linear-gradient(135deg,#4a7eb5,#2d5a8a);
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 700; color: #fff;
      overflow: hidden; flex-shrink: 0; border: 2px solid rgba(0,0,0,.1);
    }
    .user-avatar img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
    .user-info { display: flex; flex-direction: column; line-height: 1.2; }
    .user-greeting { font-size: 9px; color: #999; letter-spacing: .03em; }
    .user-name { font-size: 12px; font-weight: 600; color: #222; max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  `]
})
export class NavbarComponent {
  @Input() userName  = 'User Name';
  @Input() userPhoto = '';

  constructor(public router: Router) {}

  getInitials(): string {
    return this.userName.split(' ')
      .map(w => w[0]).join('').slice(0, 2).toUpperCase();
  }
}
