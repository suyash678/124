import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-ship-bg',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="ship-bg" aria-hidden="true">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 900" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="gSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#181410"/>
            <stop offset="1" stop-color="#1a1209"/>
          </linearGradient>
          <linearGradient id="gBulb" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0"   stop-color="#504a38"/>
            <stop offset="0.4" stop-color="#d4c8a0"/>
            <stop offset="1"   stop-color="#2a2820"/>
          </linearGradient>
          <linearGradient id="gFloor" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#c85a18"/>
            <stop offset="1" stop-color="#181008"/>
          </linearGradient>
          <radialGradient id="gGlow" cx="55%" cy="45%" r="30%">
            <stop offset="0" stop-color="#fff8e0" stop-opacity="0.16"/>
            <stop offset="1" stop-color="#000"    stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="gVign" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0.55" stop-color="#000" stop-opacity="0"/>
            <stop offset="1"    stop-color="#000" stop-opacity="0.6"/>
          </linearGradient>
        </defs>
        <rect width="1920" height="900" fill="url(#gSky)"/>
        <rect x="0" y="720" width="1920" height="180" fill="url(#gFloor)"/>
        <rect x="-20" y="55" width="830" height="750" fill="#0d0c09"/>
        <rect x="-20" y="55" width="830" height="145" fill="#bf4510"/>
        <rect x="-20" y="198" width="830" height="3" fill="#111008" opacity="0.8"/>
        <ellipse cx="840" cy="555" rx="345" ry="305" fill="url(#gBulb)"/>
        <ellipse cx="790" cy="485" rx="145" ry="125" fill="#e8dbb8" opacity="0.20"/>
        <ellipse cx="810" cy="460" rx="60"  ry="55"  fill="#fff8e8" opacity="0.12"/>
        <rect x="780" y="55"  width="1160" height="145" fill="#c04010"/>
        <rect x="780" y="200" width="1160" height="560" fill="#0f0d0a"/>
        <rect x="780" y="195" width="1160" height="7"   fill="#888070" opacity="0.4"/>
        <circle cx="1340" cy="625" r="112" fill="#0c0a07"/>
        <circle cx="1340" cy="625" r="90"  fill="#080706"/>
        <circle cx="1550" cy="650" r="96"  fill="#0c0a07"/>
        <circle cx="1550" cy="650" r="76"  fill="#080706"/>
        <circle cx="1140" cy="122" r="38" fill="none" stroke="#fff" stroke-width="5" opacity="0.68"/>
        <circle cx="1140" cy="122" r="25" fill="none" stroke="#fff" stroke-width="3" opacity="0.45"/>
        <line x1="1112" y1="122" x2="1168" y2="122" stroke="#fff" stroke-width="4" opacity="0.5"/>
        <line x1="1140" y1="94"  x2="1140" y2="150" stroke="#fff" stroke-width="4" opacity="0.5"/>
        <circle cx="1340" cy="120" r="38" fill="none" stroke="#fff" stroke-width="5" opacity="0.62"/>
        <polygon points="1360,109 1360,132 1384,121" fill="#fff" opacity="0.65"/>
        <circle cx="1520" cy="120" r="38" fill="none" stroke="#fff" stroke-width="5" opacity="0.60"/>
        <line x1="1500" y1="120" x2="1540" y2="120" stroke="#fff" stroke-width="4" opacity="0.55"/>
        <rect x="278" y="820" width="14" height="30" fill="#111" rx="2"/>
        <rect x="296" y="820" width="14" height="30" fill="#111" rx="2"/>
        <rect x="280" y="772" width="12" height="52" fill="#e07020"/>
        <rect x="297" y="775" width="12" height="50" fill="#d06018"/>
        <rect x="271" y="710" width="38" height="66" fill="#e87820" rx="2"/>
        <rect x="271" y="740" width="38" height="7"  fill="#ffe040" opacity="0.8"/>
        <rect x="254" y="715" width="18" height="10" fill="#e07020" rx="2"/>
        <rect x="246" y="724" width="12" height="32" fill="#e07020" rx="2"/>
        <ellipse cx="291" cy="700" rx="20" ry="16" fill="#e0e0d8"/>
        <rect x="271" y="694" width="40" height="11" fill="#d0d0c8" rx="4"/>
        <line x1="0"   y1="410" x2="118" y2="82"  stroke="#28231a" stroke-width="8"  opacity="0.55"/>
        <line x1="118" y1="82"  x2="210" y2="82"  stroke="#28231a" stroke-width="6"  opacity="0.45"/>
        <rect x="148" y="248" width="7"  height="205" fill="#242018" opacity="0.65"/>
        <rect x="148" y="248" width="42" height="6"   fill="#242018" opacity="0.65"/>
        <rect width="1920" height="900" fill="url(#gGlow)"/>
        <rect width="1920" height="900" fill="url(#gVign)"/>
      </svg>
    </div>
  `,
  styles: [`
    .ship-bg {
      position: fixed;
      inset: 0;
      z-index: 0;
      overflow: hidden;
      background: #0a0905;
    }
    .ship-bg svg { width: 100%; height: 100%; display: block; }
  `]
})
export class ShipBgComponent {}
