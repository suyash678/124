import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ShipInfoService } from '../../services/shipinfo.service';
import {
  ShipInfoSearchRequest, ShipInfoFilter,
  ActiveFilter, ColumnDef, VesselRow
} from '../../models/shipinfo.models';
import { ALL_COLUMNS, CATEGORIES } from '../../models/columns';

const MAX_COLUMNS = 25;

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  // ── Column selector state ─────────────────────────────────────────────────
  readonly allColumns   = ALL_COLUMNS;
  readonly categories   = CATEGORIES;
  readonly maxColumns   = MAX_COLUMNS;

  selectedColumns: ColumnDef[] = [];       // user's chosen columns (max 25)
  selectorOpen      = false;
  selectorSearch    = '';
  selectorCategory  = 'All';

  get filteredColumns(): ColumnDef[] {
    return this.allColumns.filter(c => {
      const matchCat = this.selectorCategory === 'All' || c.category === this.selectorCategory;
      const matchQ   = !this.selectorSearch ||
        c.label.toLowerCase().includes(this.selectorSearch.toLowerCase());
      return matchCat && matchQ;
    });
  }

  isSelected(col: ColumnDef): boolean {
    return this.selectedColumns.some(c => c.column === col.column);
  }

  toggleColumn(col: ColumnDef): void {
    if (this.isSelected(col)) {
      this.selectedColumns = this.selectedColumns.filter(c => c.column !== col.column);
    } else if (this.selectedColumns.length < MAX_COLUMNS) {
      this.selectedColumns = [...this.selectedColumns, col];
    }
  }

  removeColumn(col: ColumnDef): void {
    this.selectedColumns = this.selectedColumns.filter(c => c.column !== col.column);
    // also remove any filter on this column
    this.activeFilters = this.activeFilters.filter(f => f.def.column !== col.column);
  }

  setSelectorCategory(cat: string): void { this.selectorCategory = cat; }

  // ── Filter state ──────────────────────────────────────────────────────────
  activeFilters: ActiveFilter[] = [];

  readonly operators: Array<{ value: ShipInfoFilter['Operator']; label: string }> = [
    { value: 'equals',      label: 'Equals'       },
    { value: 'contains',    label: 'Contains'     },
    { value: 'startswith',  label: 'Starts with'  },
    { value: 'gte',         label: '>= (min)'     },
    { value: 'lte',         label: '<= (max)'     },
    { value: 'range',       label: 'Range'        },
  ];

  addFilter(col: ColumnDef): void {
    // don't add duplicate
    if (this.activeFilters.some(f => f.def.column === col.column)) return;
    this.activeFilters = [...this.activeFilters, {
      def: col, operator: 'contains', value: '', value2: ''
    }];
  }

  removeFilter(index: number): void {
    this.activeFilters = this.activeFilters.filter((_, i) => i !== index);
  }

  updateFilterOperator(index: number, op: ShipInfoFilter['Operator']): void {
    this.activeFilters = this.activeFilters.map((f, i) =>
      i === index ? { ...f, operator: op, value: '', value2: '' } : f
    );
  }

  updateFilterValue(index: number, val: string): void {
    this.activeFilters = this.activeFilters.map((f, i) =>
      i === index ? { ...f, value: val } : f
    );
  }

  updateFilterValue2(index: number, val: string): void {
    this.activeFilters = this.activeFilters.map((f, i) =>
      i === index ? { ...f, value2: val } : f
    );
  }

  // ── Search state ──────────────────────────────────────────────────────────
  results:      VesselRow[] = [];
  visibleResults: VesselRow[] = [];
  loading       = false;
  errorMsg      = '';
  hasSearched   = false;

  // Table state
  sortColumn    = '';
  sortAsc       = true;
  filterText    = '';
  currentPage   = 1;
  pageSize      = 20;

  get totalPages(): number {
    return Math.ceil(this.filteredRows.length / this.pageSize) || 1;
  }

  get filteredRows(): VesselRow[] {
    if (!this.filterText.trim()) return this.results;
    const q = this.filterText.toLowerCase();
    return this.results.filter(row =>
      Object.values(row).some(v => String(v ?? '').toLowerCase().includes(q))
    );
  }

  get pagedRows(): VesselRow[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredRows.slice(start, start + this.pageSize);
  }

  get pages(): number[] {
    const total = this.totalPages;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const cur = this.currentPage;
    const pages: number[] = [1];
    if (cur > 3) pages.push(-1);
    for (let i = Math.max(2, cur - 1); i <= Math.min(total - 1, cur + 1); i++) pages.push(i);
    if (cur < total - 2) pages.push(-1);
    if (total > 1) pages.push(total);
    return pages;
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────
  constructor(private shipInfoService: ShipInfoService) {}

  ngOnInit(): void {
    // Default: select first 5 identity columns
    this.selectedColumns = ALL_COLUMNS.slice(0, 5);
  }

  // ── Build & send request ──────────────────────────────────────────────────
  search(): void {
    if (this.selectedColumns.length === 0) {
      this.errorMsg = 'Please select at least one column.';
      return;
    }

    const filters: ShipInfoFilter[] = this.activeFilters
      .filter(f => f.value.trim() !== '')
      .map(f => {
        if (f.operator === 'range') {
          return { Column: f.def.column, Operator: 'range', Value: [f.value, f.value2 ?? ''] };
        }
        const numericOps = ['gte', 'lte'];
        const val = numericOps.includes(f.operator) ? Number(f.value) || f.value : f.value;
        return { Column: f.def.column, Operator: f.operator, Value: val };
      });

    const request: ShipInfoSearchRequest = {
      SelectedColumns: this.selectedColumns.map(c => c.column),
      Filters: filters
    };

    this.loading    = true;
    this.errorMsg   = '';
    this.hasSearched = true;
    this.results    = [];
    this.currentPage = 1;
    this.filterText = '';

    this.shipInfoService.search(request).subscribe({
      next: (rows) => {
        this.results = rows;
        this.loading = false;
      },
      error: (err: Error) => {
        this.errorMsg = err.message;
        this.loading  = false;
      }
    });
  }

  clearAll(): void {
    this.activeFilters  = [];
    this.results        = [];
    this.hasSearched    = false;
    this.errorMsg       = '';
    this.filterText     = '';
    this.currentPage    = 1;
  }

  // ── Table interactions ────────────────────────────────────────────────────
  sortBy(col: string): void {
    if (this.sortColumn === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortColumn = col;
      this.sortAsc = true;
    }
    this.results = [...this.results].sort((a, b) => {
      const av = String(a[col] ?? '');
      const bv = String(b[col] ?? '');
      return this.sortAsc ? av.localeCompare(bv, undefined, { numeric: true })
                          : bv.localeCompare(av, undefined, { numeric: true });
    });
    this.currentPage = 1;
  }

  goToPage(p: number): void {
    if (p < 1 || p > this.totalPages) return;
    this.currentPage = p;
  }

  // ── Export CSV ────────────────────────────────────────────────────────────
  exportCSV(): void {
    if (!this.results.length) return;
    const cols  = this.selectedColumns.map(c => c.column);
    const heads = this.selectedColumns.map(c => `"${c.label}"`).join(',');
    const rows  = this.results.map(r =>
      cols.map(c => `"${String(r[c] ?? '').replace(/"/g, '""')}"`).join(',')
    );
    const csv  = [heads, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = `shipinfo_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  getCellClass(col: ColumnDef, value: unknown): string {
    const v = String(value ?? '').toLowerCase();
    if (col.column === 'SanctionsStatus' && v !== 'clear' && v !== '') return 'cell-warn';
    if (col.column === 'CIIRating' && ['a','b'].includes(v)) return 'cell-good';
    if (col.column === 'CIIRating' && ['d','e'].includes(v)) return 'cell-warn';
    if (col.column === 'AISStatus' && v.includes('way'))  return 'cell-transit';
    if (col.column === 'AISStatus' && v.includes('anchor')) return 'cell-anchor';
    return '';
  }

  trackByIndex(index: number): number { return index; }

  getColByName(column: string): ColumnDef {
    return this.allColumns.find(c => c.column === column) ?? this.allColumns[0];
  }

  getValuePlaceholder(f: ActiveFilter): string {
    switch (f.operator) {
      case 'equals':     return 'exact value';
      case 'contains':   return 'partial match';
      case 'startswith': return 'starts with…';
      case 'gte':        return 'min value';
      case 'lte':        return 'max value';
      default:           return 'value';
    }
  }

}
