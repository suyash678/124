import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `
    <div class="hero">
      <h1 class="hero-title">SHIPINFO</h1>
    </div>
  `,
  styles: [`
    .hero {
      position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      background: transparent;
    }
    .hero-title {
      font-family: 'Barlow Condensed', sans-serif;
      font-weight: 900;
      font-size: clamp(72px, 10vw, 152px);
      letter-spacing: .18em;
      color: #fff;
      text-transform: uppercase;
      text-shadow: 0 2px 28px rgba(0,0,0,.32);
      user-select: none;
    }
  `]
})
export class HomeComponent {
  constructor(public router: Router) {}
}
