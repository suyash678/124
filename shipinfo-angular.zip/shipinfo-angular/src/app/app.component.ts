import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ShipBgComponent } from './components/ship-bg/ship-bg.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, ShipBgComponent],
  template: `
    <app-ship-bg></app-ship-bg>
    <app-navbar></app-navbar>
    <main class="main-content">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    :host { display: block; height: 100vh; overflow: hidden; }
    .main-content {
      position: fixed;
      top: var(--nav-h);
      left: 0; right: 0; bottom: 0;
      z-index: 1;
    }
  `]
})
export class AppComponent {}
