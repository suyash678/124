export const environment = {
  production: false,
  apiBase: '/api/shipinfo'
};
