export const environment = {
  production: true,
  apiBase: '/api/shipinfo'   // same route in production
};
