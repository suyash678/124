# ShipInfo Frontend

React + Vite frontend for the ShipInfo Maritime Intelligence platform.

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev        # http://localhost:3000
```

Make sure your **ShipInfo_API** backend is running on port 5000.

## API Contract

The frontend connects to:

```
POST /api/shipinfo/search
Content-Type: application/json

{
  "SelectedColumns": ["VesselName", "IMONumber", "FlagState", ...],
  "Filters": [
    { "Column": "FlagState",    "Operator": "equals",     "Value": "Panama" },
    { "Column": "GrossTonnage", "Operator": "gte",        "Value": 50000    },
    { "Column": "VesselName",   "Operator": "contains",   "Value": "EVER"   },
    { "Column": "YearBuilt",    "Operator": "startswith", "Value": "202"    }
  ]
}
```

**Supported operators** (match your ShipInfoQueryService):
| Frontend syntax | Operator sent    |
|----------------|-----------------|
| `Panama`       | `contains`      |
| `=Panama`      | `equals`        |
| `Pan*`         | `startswith`    |
| `>50000`       | `gte`           |
| `<=100`        | `lte`           |
| `2010-2020`    | `gte` + `lte`   |
| `Bulk\|\|Tanker` | `contains` ×2 |

## Project Structure

```
src/
├── App.jsx                        # Root — routing + SSO state
├── main.jsx
├── index.css                      # CSS variables
├── components/
│   ├── Nav/          Nav.jsx+css  # Logo | links | user pill
│   ├── Hero/         HeroView.jsx # Landing page — ship hull hero
│   ├── Search/       SearchView.jsx # 300-parameter search workspace
│   └── Support/      SupportView.jsx # Support form → POST /api/shipinfo/support
├── hooks/
│   └── useSearch.js               # Bridges engine state → Nav buttons
└── utils/
    ├── searchEngine.js            # Full search engine + API integration
    ├── api.js                     # HTTP helpers
    └── manual.js                  # PDF download
```

## SSO Integration (Microsoft MSAL)

After login, call:
```js
window.setUserFromSSO({
  displayName: accounts[0].name,
  email:       accounts[0].username,
  photo:       photoDataUri,          // optional — MS Graph /me/photo
});
```

## Company Logo

In `Nav.jsx`, replace the placeholder SVG with your actual logo:
```jsx
<img src="/assets/logo.svg" alt="Company"/>
```
And update the `"YourCo"` text to your company name.

## User Manual PDF

Place your PDF at `public/ShipInfo-UserManual.pdf`, then in `utils/manual.js`
switch to Option A (direct link).

## Production Build

```bash
npm run build    # outputs to dist/
```

Deploy `dist/` to any static host, or copy into your API's `wwwroot/`.
