import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      // Proxy all /api calls to your ShipInfo_API backend
      // Change the port if your API runs on a different port
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
        // If your API has CORS issues during dev, this handles it
        rewrite: path => path,
      }
    }
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  }
});
