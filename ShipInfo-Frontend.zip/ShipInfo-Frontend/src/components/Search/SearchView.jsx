import { useEffect, useRef } from 'react';
import './SearchView.css';
import { searchEngine } from '../../utils/searchEngine.js';

/**
 * SearchView mounts the ShipInfo search engine into a React component.
 *
 * The engine (searchEngine.js) contains all the search state, filter logic,
 * mock data generation, and DOM manipulation — preserved exactly from the
 * original single-file HTML.
 *
 * The Nav component calls engine methods via the searchState prop wired
 * through App.jsx.
 */
export default function SearchView({ user }) {
  const mounted = useRef(false);

  useEffect(() => {
    if (mounted.current) return;
    mounted.current = true;
    // Boot the search engine once the DOM is ready
    searchEngine.init();
  }, []);

  return (
    <div className="search-view" id="searchView">

      {/* Stats bar */}
      <div className="stats-bar" id="statsBar">
        <div className="stat-item ac"><div className="stat-icon">🚢</div><div className="stat-info"><div className="stat-val" id="stTotal">—</div><div className="stat-lbl">Total Vessels</div></div></div>
        <div className="stat-item"   ><div className="stat-icon">🏴</div><div className="stat-info"><div className="stat-val" id="stFlags">—</div><div className="stat-lbl">Flag States</div></div></div>
        <div className="stat-item gr"><div className="stat-icon">🟢</div><div className="stat-info"><div className="stat-val" id="stActive">—</div><div className="stat-lbl">Active / Transit</div></div></div>
        <div className="stat-item go"><div className="stat-icon">⚓</div><div className="stat-info"><div className="stat-val" id="stAnchor">—</div><div className="stat-lbl">At Anchor</div></div></div>
        <div className="stat-item re"><div className="stat-icon">⚠️</div><div className="stat-info"><div className="stat-val" id="stSanc">—</div><div className="stat-lbl">Flagged</div></div></div>
        <div className="stat-item pu"><div className="stat-icon">📦</div><div className="stat-info"><div className="stat-val" id="stGrt">—</div><div className="stat-lbl">Avg GRT</div></div></div>
      </div>

      {/* Toolbar */}
      <div className="toolbar">
        <div className="search-wrap">
          <span className="search-icon">⌕</span>
          <input className="field-search" type="text" placeholder="Search visible fields…"
            id="fieldSearchInput" onInput={e => searchEngine.onFS(e.target.value)}/>
        </div>
        <div className="preset-row" id="presetRow"></div>
        <div className="cat-chips"  id="catChips"></div>
      </div>

      {/* Operator legend */}
      <div className="op-legend">
        <span className="op-legend-title">OPERATORS:</span>
        <span className="op-legend-ex">&gt;50000 · &lt;=10 · 2020-2024 · !Panama · Pan* · Bulk||Tanker · empty · !empty</span>
        <span className="op-legend-hint">Click ⊕ on any field for examples</span>
      </div>

      {/* Body */}
      <div className="body-split">

        {/* Field configurator */}
        <div className="configurator" id="configurator">
          <div className="cfg-hdr">
            <div className="cfg-title">Field Selector</div>
            <div className="cfg-subtitle" id="cfgSub">Select up to 25 fields</div>
          </div>
          <div className="cfg-sw">
            <span style={{color:'var(--text-dim)',fontSize:12}}>⌕</span>
            <input type="text" placeholder="Search 300 fields…" id="cfgSI"
              onInput={() => searchEngine.renderCfgList()}/>
          </div>
          <div className="ostrip" id="ostrip"></div>
          <div className="cfg-body" id="cfgBody"></div>
          <div className="cfg-foot">
            <div className="cfg-count" id="cfgCount"><span className="n">0</span>/<span className="m">25</span></div>
            <div className="cfg-acts">
              <button className="cfg-btn" onClick={() => searchEngine.selTopN(25)}>Top 25</button>
              <button className="cfg-btn" onClick={() => searchEngine.clearCfgSel()}>Clear</button>
              <button className="cfg-btn apply" onClick={() => searchEngine.applyFieldSel()}>Apply ✓</button>
            </div>
          </div>
        </div>

        {/* Field canvas */}
        <div className="field-canvas">
          <div className="canvas-top">
            <span className="showing-lbl" id="showingLbl">No fields selected</span>
            <div className="sel-tags" id="selTagsRow"></div>
          </div>
          <div className="fields-scroll">
            <div className="fields-grid" id="fieldsGrid"></div>
            <div className="empty-state" id="emptyState" style={{display:'none'}}>
              <div className="empty-icon">🔭</div>
              <p>No fields match.</p>
              <button className="cfg-btn" onClick={() => searchEngine.clearFS()}>Clear search</button>
            </div>
            <div className="empty-state" id="noSelState" style={{display:'none'}}>
              <div className="empty-icon">⚙️</div>
              <p>No fields selected yet.</p>
              <button className="cfg-btn" onClick={() => searchEngine.toggleConfigurator()}>⚙ Open Field Selector</button>
            </div>
          </div>
          <footer className="pagination-bar" id="paginationBar"></footer>
        </div>
      </div>

      {/* Results panel */}
      <div className="results-panel" id="resultsPanel">
        <div className="rp-hdr">
          <span className="rp-title">Search Results</span>
          <span className="rp-count" id="rpCount">—</span>
          <span className="rp-ci" id="rpCI"></span>
          <button className="cfg-btn" onClick={() => searchEngine.exportCSV()} style={{fontSize:11,padding:'3px 9px'}}>⬇ CSV</button>
          <button className="rp-close" onClick={() => searchEngine.closeResults()}>✕ Close</button>
        </div>
        <div className="rp-fbar">
          <span style={{fontSize:10,color:'var(--text-dim)',fontFamily:'Inter,monospace',whiteSpace:'nowrap'}}>Filter rows:</span>
          <input className="rp-fi" type="text" placeholder="Name, IMO, value…" id="rpFI"
            onInput={() => searchEngine.renderRT()}/>
          <div className="col-toggles" id="colToggles"></div>
        </div>
        <div className="rp-twrap"><table className="rp-table"><thead id="rpThead"></thead><tbody id="rpTbody"></tbody></table></div>
        <div className="rp-pg" id="rpPg"></div>
      </div>

      {/* Charts panel */}
      <div className="charts-panel" id="chartsPanel">
        <div className="cp-hdr">
          <span className="cp-title">📈 Result Distribution</span>
          <span style={{fontSize:10,color:'var(--text-dim)',fontFamily:'Inter,monospace'}} id="cpSub">Run a search first</span>
          <button className="cp-close" onClick={() => searchEngine.toggleCharts()}>✕</button>
        </div>
        <div className="charts-grid" id="chartsGrid"></div>
      </div>

      {/* Saved panel */}
      <div className="saved-panel" id="savedPanel">
        <div className="sp-hdr">
          <span className="sp-title">Saved &amp; History</span>
          <button className="sp-close" onClick={() => searchEngine.toggleSaved()}>✕</button>
        </div>
        <div className="sp-tabs">
          <button className="sp-tab active" id="tabSaved" onClick={() => searchEngine.switchTab('saved')}>💾 Saved</button>
          <button className="sp-tab"        id="tabHist"  onClick={() => searchEngine.switchTab('history')}>🕐 History</button>
        </div>
        <div className="sp-body" id="spBody"></div>
        <div className="sp-foot">
          <button className="cfg-btn apply" style={{width:'100%',justifyContent:'center'}}
            onClick={() => searchEngine.saveCurrentSearch()}>
            + Save Current Search
          </button>
        </div>
      </div>

      {/* Detail drawer */}
      <div className="detail-drawer" id="detailDrawer">
        <div className="dd-hdr">
          <div><div className="dd-name" id="ddName">—</div><div className="dd-imo" id="ddImo">—</div></div>
          <button className="dd-close" onClick={() => searchEngine.closeDetail()}>✕</button>
        </div>
        <div className="dd-status" id="ddStatus"></div>
        <div className="dd-body"   id="ddBody"></div>
      </div>

      {/* Save modal */}
      <div className="modal-backdrop" id="saveModal">
        <div className="modal">
          <div className="modal-hdr">
            <span className="modal-title">Save Search</span>
            <button className="modal-close" onClick={() => searchEngine.closeSM()}>✕</button>
          </div>
          <p style={{fontSize:11,color:'var(--text-dim)',marginBottom:10}}>Name this configuration to reload it later.</p>
          <input className="modal-input" type="text" id="saveNameInput"
            placeholder="e.g. Bulk Carriers Asia — Overdue Survey" maxLength={60}/>
          <div style={{fontSize:10,color:'var(--text-dim)',marginBottom:7}} id="saveSummary"></div>
          <div className="modal-row">
            <button className="modal-btn" onClick={() => searchEngine.closeSM()}>Cancel</button>
            <button className="modal-btn confirm" onClick={() => searchEngine.confirmSave()}>Save Search</button>
          </div>
        </div>
      </div>

      {/* Keyboard shortcuts overlay */}
      <div className="sc-overlay" id="scOverlay" onClick={() => searchEngine.closeSC()}>
        <div className="sc-box" onClick={e => e.stopPropagation()}>
          <div className="sc-title">⌨ Keyboard Shortcuts</div>
          <div className="sc-grid">
            {[['Show shortcuts','?'],['Run Search','Ctrl ↵'],['Focus field search','/'],['Toggle Configurator','Ctrl F'],
              ['Saved Searches','Ctrl S'],['Close panels','Esc'],['Toggle Charts','Ctrl G'],
              ['Clear all filters','Ctrl D'],['Export CSV','Ctrl E']
            ].map(([desc, keys]) => (
              <div className="sc-row" key={desc}>
                <span className="sc-desc">{desc}</span>
                <div className="sc-keys">{keys.split(' ').map(k => <span className="kbd" key={k}>{k}</span>)}</div>
              </div>
            ))}
          </div>
          <p style={{textAlign:'center',fontSize:10,color:'var(--text-dim)',marginTop:12}}>
            Press <span className="kbd">Esc</span> to close
          </p>
        </div>
      </div>

      {/* Toast container */}
      <div className="toast-ct" id="toastCt"></div>

    </div>
  );
}
