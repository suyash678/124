import './Nav.css';
import { downloadManual } from '../../utils/manual.js';

/**
 * Three-zone navigation bar:
 *  Left   — Company logo (replace SVG/text with your brand)
 *  Centre — Advanced Search | Support | User Manual
 *  Right  — Search action buttons (search view only) + SSO user identity
 */
export default function Nav({ view, setView, user, searchState }) {
  const { activeCount = 0, savedCount = 0, cfgSelCount = '0/25',
          onToggleSaved, onToggleConfigurator, onToggleCharts,
          onClearAll, onRunSearch, onOpenShortcuts,
          hasActiveFilters = false } = searchState || {};

  const initials = user?.displayName
    ? user.displayName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : '?';

  return (
    <nav className="nav">

      {/* ── LEFT: Company logo ───────────────────────────────────────── */}
      <div className="nav-left">
        <button className="company-logo" onClick={() => setView('hero')} title="Home">
          <div className="company-logo-mark">
            {/*
              Replace this SVG with:
              <img src="/assets/company-logo.svg" alt="Company logo" />
            */}
            <svg viewBox="0 0 24 24">
              <path d="M2 20h20v2H2zM4 14h4v6H4zm6-4h4v10h-4zm6-5h4v15h-4z"/>
            </svg>
          </div>
          <div className="company-logo-text">
            <span className="company-name">YourCo</span>
            <span className="company-tagline">Maritime Intelligence</span>
          </div>
        </button>
      </div>

      {/* ── CENTRE: Navigation links ─────────────────────────────────── */}
      <div className="nav-centre">
        <div className="nav-links">
          <button
            className={`nav-link${view === 'search' ? ' active' : ''}`}
            onClick={() => setView('search')}
          >
            Advanced Search
          </button>
          <button
            className={`nav-link${view === 'support' ? ' active' : ''}`}
            onClick={() => setView('support')}
          >
            Support
          </button>
          <button
            className="nav-link"
            onClick={downloadManual}
          >
            User Manual
          </button>
        </div>
      </div>

      {/* ── RIGHT: Search actions + user pill ────────────────────────── */}
      <div className="nav-right">

        {/* Search actions — visible only in search view */}
        {view === 'search' && (
          <div className="search-actions">
            <span className={`active-count${activeCount > 0 ? ' has' : ''}`}>
              {activeCount > 0 && <span className="dot"/>}
              {activeCount > 0 ? `${activeCount} filter${activeCount !== 1 ? 's' : ''}` : '0 filters'}
            </span>
            <button className="sact-btn sact-ghost" onClick={onToggleSaved}
              title="Saved searches">
              💾 <span style={{ fontFamily: 'Inter,monospace', fontSize: 10, opacity: .75 }}>({savedCount})</span>
            </button>
            <button className="sact-btn sact-ghost" onClick={onToggleConfigurator}
              title="Field selector">
              ⚙ <span style={{ fontFamily: 'Inter,monospace', fontSize: 10, opacity: .75 }}>({cfgSelCount})</span>
            </button>
            <button className="sact-btn sact-ghost" onClick={onToggleCharts} title="Charts">📈</button>
            <button className="sact-btn sact-ghost" onClick={onClearAll}
              disabled={!hasActiveFilters} title="Clear all filters">
              Clear
            </button>
            <button className="sact-btn sact-primary" onClick={onRunSearch}>Search →</button>
            <button className="sact-btn sact-ghost" onClick={onOpenShortcuts}
              style={{ padding: '5px 8px' }} title="Keyboard shortcuts">
              ⌨
            </button>
          </div>
        )}

        {/* User identity pill — populated from SSO */}
        <button className="user-pill" title={user?.email || 'Account'}>
          <div className="user-avatar">
            {user?.photo
              ? <img src={user.photo} alt={user.displayName}/>
              : <span>{initials}</span>
            }
          </div>
          <div className="user-info">
            <span className="user-greeting">Welcome</span>
            <span className="user-name">{user?.displayName || 'User'}</span>
          </div>
          <span className="user-chevron">▾</span>
        </button>

      </div>
    </nav>
  );
}
