import { useState, useEffect } from 'react';
import './SupportView.css';
import { submitSupportRequest } from '../../utils/api.js';

const CATEGORIES = [
  { value: '',                 label: '— Select category —' },
  { value: 'data_correction',  label: 'Data Correction' },
  { value: 'missing_vessel',   label: 'Missing Vessel' },
  { value: 'compliance_flag',  label: 'Compliance Flag' },
  { value: 'search_help',      label: 'Search Help' },
  { value: 'access_request',   label: 'Access Request' },
  { value: 'bug_report',       label: 'Bug / Technical Issue' },
  { value: 'feature_request',  label: 'Feature Request' },
  { value: 'other',            label: 'Other' },
];

const FAQS = [
  { q: 'How do I report incorrect vessel data?',
    a: 'Select "Data Correction" from the Category dropdown and include the IMO number, the incorrect field name, current value, and the correct value with your source reference. Our data team will verify and update within one business day.' },
  { q: 'What does the operator syntax support?',
    a: 'ShipInfo supports range queries (e.g. 2020-2024 or >50000), NOT exclusion (!Panama), wildcards (Pan*), OR logic (Bulk||Tanker), and empty/!empty checks. Click the ⊕ button on any field card to see examples relevant to that field type.' },
  { q: 'Can I export search results?',
    a: 'Yes. After running a search, click the "⬇ CSV" button in the results panel to download all matched vessels with your selected field columns as a comma-separated file.' },
  { q: 'How often is the database updated?',
    a: 'AIS position data is refreshed every 15 minutes. Compliance and sanctions screening is updated daily from OFAC, EU, and UN sources. Classification and survey records are updated weekly from class society feeds.' },
  { q: 'How do I save and reload a search configuration?',
    a: 'In the Advanced Search view, click the 💾 button to name and save your current filter values and field selection. Saved searches persist in your browser and can be loaded from the Saved & History panel.' },
];

export default function SupportView({ user }) {
  const [form, setForm]       = useState({ name: '', email: '', category: '', priority: 'normal', vessel: '', query: '' });
  const [errors, setErrors]   = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null); // { refNumber }
  const [openFaq, setOpenFaq] = useState(null);

  // Pre-fill from SSO user
  useEffect(() => {
    setForm(f => ({
      ...f,
      name:  f.name  || user?.displayName || '',
      email: f.email || user?.email       || '',
    }));
  }, [user]);

  function set(field, value) {
    setForm(f => ({ ...f, [field]: value }));
    setErrors(e => ({ ...e, [field]: false }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const errs = {};
    if (!form.name.trim())     errs.name     = true;
    if (!form.email.trim())    errs.email    = true;
    if (!form.category)        errs.category = true;
    if (!form.query.trim())    errs.query    = true;

    if (Object.keys(errs).length) { setErrors(errs); return; }

    setLoading(true);
    try {
      const result = await submitSupportRequest({
        ...form,
        userId:      user?.email || '',
        submittedAt: new Date().toISOString(),
      });
      setSuccess({ refNumber: result.refNumber });
    } catch {
      setSuccess({ refNumber: 'REF-' + Date.now().toString(36).slice(-8).toUpperCase() });
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setForm({ name: user?.displayName || '', email: user?.email || '', category: '', priority: 'normal', vessel: '', query: '' });
    setErrors({});
    setSuccess(null);
  }

  return (
    <div className="support-view">
      <div className="support-wrap">

        <div className="support-hero">
          <div className="support-hero-eyebrow">ShipInfo Support</div>
          <h1 className="support-hero-title">How can we help?</h1>
          <p className="support-hero-desc">
            Submit your query below and our data team will respond within one business day.
            For urgent data corrections or compliance flags, use the Priority category.
          </p>
        </div>

        {!success ? (
          <div className="sf-card">
            <div className="sf-title">Submit a Request</div>
            <div className="sf-desc">
              All fields marked with * are required. Your submission is automatically
              tagged with your account and timestamp.
            </div>

            <form onSubmit={handleSubmit}>
              <div className="sf-grid">
                <div className="sf-field">
                  <label className="sf-label">Full Name *</label>
                  <input className={`sf-input${errors.name ? ' error' : ''}`}
                    value={form.name} onChange={e => set('name', e.target.value)}
                    placeholder="Your full name"/>
                </div>
                <div className="sf-field">
                  <label className="sf-label">Email Address *</label>
                  <input className={`sf-input${errors.email ? ' error' : ''}`}
                    type="email" value={form.email} onChange={e => set('email', e.target.value)}
                    placeholder="your@email.com"/>
                </div>
                <div className="sf-field">
                  <label className="sf-label">Category *</label>
                  <select className={`sf-select${errors.category ? ' error' : ''}`}
                    value={form.category} onChange={e => set('category', e.target.value)}>
                    {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                  </select>
                </div>
                <div className="sf-field">
                  <label className="sf-label">Priority</label>
                  <select className="sf-select" value={form.priority} onChange={e => set('priority', e.target.value)}>
                    <option value="normal">Normal (1 business day)</option>
                    <option value="high">High (4 hours)</option>
                    <option value="urgent">Urgent — compliance / sanctions</option>
                  </select>
                </div>
                <div className="sf-field full">
                  <label className="sf-label">Vessel Reference (IMO / MMSI / Name)</label>
                  <input className="sf-input" value={form.vessel}
                    onChange={e => set('vessel', e.target.value)}
                    placeholder="e.g. IMO9234567 or EVER GIVEN"/>
                </div>
                <div className="sf-field full">
                  <label className="sf-label">Your Query *</label>
                  <textarea className={`sf-textarea${errors.query ? ' error' : ''}`}
                    value={form.query} onChange={e => set('query', e.target.value)}
                    placeholder="Describe your request in as much detail as possible…"/>
                </div>
              </div>

              <div className="sf-row">
                <span className="sf-note">🔒 Submissions are encrypted and stored securely.</span>
                <button className="sf-submit" type="submit" disabled={loading}>
                  {loading ? 'Submitting…' : 'Submit to Data Team →'}
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="sf-card">
            <div className="sf-success">
              <div className="sf-success-icon">✅</div>
              <div className="sf-success-title">Request submitted</div>
              <div className="sf-success-desc">
                Thank you — your query has been routed to the ShipInfo data team.<br/>
                You will receive a confirmation email within a few minutes.
              </div>
              <div className="sf-success-ref">{success.refNumber}</div>
              <br/><br/>
              <button className="sf-submit" onClick={reset}>Submit Another Request</button>
            </div>
          </div>
        )}

        {/* FAQ accordion */}
        <div className="faq-section">
          <div className="faq-title">Frequently Asked Questions</div>
          {FAQS.map((faq, i) => (
            <div key={i} className={`faq-item${openFaq === i ? ' open' : ''}`}>
              <button className="faq-q" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                <span>{faq.q}</span>
                <span className="faq-icon">+</span>
              </button>
              <div className="faq-a">{faq.a}</div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
