import './HeroView.css';
import { downloadManual } from '../../utils/manual.js';

/**
 * Landing page — matches the reference image:
 *  - Full-bleed ship hull photograph
 *  - Giant SHIPINFO title centred on hull
 *  - Three bottom cards: Advanced Search / Support / User Manual
 */
export default function HeroView({ setView }) {
  return (
    <div className="hero-view">
      <div className="hero-bg" />

      <div className="hero-body">
        <h1 className="hero-title">ShipInfo</h1>
        <p className="hero-subtitle">
          <span>Maritime Intelligence</span>
          <span className="hero-subtitle-dot">·</span>
          <span>300+ Search Parameters</span>
          <span className="hero-subtitle-dot">·</span>
          <span>Global Fleet Coverage</span>
        </p>
      </div>

      <div className="hero-cards">
        <button className="hero-card" onClick={() => setView('search')}>
          <div className="hero-card-icon">🔍</div>
          <div className="hero-card-label">Advanced Search</div>
          <div className="hero-card-desc">
            Query 300+ vessel parameters across identity, technical, compliance,
            environmental and crew data.
          </div>
          <div className="hero-card-arrow">→</div>
        </button>

        <button className="hero-card" onClick={() => setView('support')}>
          <div className="hero-card-icon">💬</div>
          <div className="hero-card-label">Support</div>
          <div className="hero-card-desc">
            Submit queries, data corrections or feature requests directly to
            the ShipInfo data team.
          </div>
          <div className="hero-card-arrow">→</div>
        </button>

        <button className="hero-card" onClick={downloadManual}>
          <div className="hero-card-icon">📄</div>
          <div className="hero-card-label">User Manual</div>
          <div className="hero-card-desc">
            Download the complete ShipInfo reference guide covering all
            parameters, operators and search techniques.
          </div>
          <div className="hero-card-arrow">↓</div>
        </button>
      </div>
    </div>
  );
}
