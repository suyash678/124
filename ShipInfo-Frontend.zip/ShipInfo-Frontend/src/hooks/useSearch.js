import { useState, useEffect, useCallback } from 'react';
import { searchEngine } from '../utils/searchEngine.js';

/**
 * useSearch
 *
 * React hook that bridges the search engine singleton with React state.
 * Returns the searchState object expected by Nav.jsx for the action buttons.
 *
 * Polls the engine every 300ms for active filter count / saved count updates
 * so the Nav stays in sync without deep integration into the engine internals.
 */
export function useSearch() {
  const [activeCount,   setActiveCount]   = useState(0);
  const [savedCount,    setSavedCount]    = useState(0);
  const [cfgSelCount,   setCfgSelCount]   = useState('0/25');

  useEffect(() => {
    const interval = setInterval(() => {
      try {
        setActiveCount(searchEngine.getActiveCount());
        setSavedCount(searchEngine.getSavedCount());
        setCfgSelCount(searchEngine.getCfgSelCount());
      } catch { /* engine not yet initialised */ }
    }, 300);
    return () => clearInterval(interval);
  }, []);

  return {
    activeCount,
    savedCount,
    cfgSelCount,
    hasActiveFilters: activeCount > 0,

    onRunSearch:         useCallback(() => searchEngine.runSearch?.(),         []),
    onToggleConfigurator:useCallback(() => searchEngine.toggleConfigurator?.(),[]),
    onToggleSaved:       useCallback(() => searchEngine.toggleSaved?.(),       []),
    onToggleCharts:      useCallback(() => searchEngine.toggleCharts?.(),      []),
    onClearAll:          useCallback(() => searchEngine.clearAll?.(),          []),
    onOpenShortcuts:     useCallback(() => searchEngine.openSC?.(),            []),
  };
}
