/**
 * manual.js — Downloads the ShipInfo User Manual PDF.
 *
 * Production: replace the generated stub with a real PDF at /public/ShipInfo-UserManual.pdf
 * and update this file to use: window.open('/ShipInfo-UserManual.pdf', '_blank')
 */

export function downloadManual() {
  // ── Option A (production): serve real PDF from public folder ─────────────
  // Uncomment once you have the actual PDF at /public/ShipInfo-UserManual.pdf
  //
  // const a = document.createElement('a');
  // a.href = '/ShipInfo-UserManual.pdf';
  // a.download = 'ShipInfo-UserManual.pdf';
  // a.click();
  // return;

  // ── Option B (current): generate a placeholder PDF ───────────────────────
  const content = `%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj
4 0 obj<</Length 680>>stream
BT /F1 26 Tf 72 720 Td (ShipInfo User Manual) Tj
0 -36 Td /F1 12 Tf (Version 1.0  |  Maritime Intelligence Platform) Tj
0 -48 Td /F1 11 Tf (CONTENTS) Tj
0 -22 Td (1.  Getting Started                   p. 3) Tj
0 -18 Td (2.  Advanced Search Overview          p. 5) Tj
0 -18 Td (3.  300+ Search Parameters Reference  p. 9) Tj
0 -18 Td (    3.1  Identity Parameters          p. 9) Tj
0 -18 Td (    3.2  Technical Parameters         p. 14) Tj
0 -18 Td (    3.3  Navigation Parameters        p. 18) Tj
0 -18 Td (    3.4  Classification Parameters    p. 21) Tj
0 -18 Td (    3.5  Ownership Parameters         p. 24) Tj
0 -18 Td (    3.6  Cargo Parameters             p. 27) Tj
0 -18 Td (    3.7  Port & Call Parameters       p. 30) Tj
0 -18 Td (    3.8  Compliance Parameters        p. 33) Tj
0 -18 Td (    3.9  Environmental Parameters     p. 36) Tj
0 -18 Td (    3.10 Crew Parameters              p. 39) Tj
0 -22 Td (4.  Operator Syntax Reference         p. 41) Tj
0 -18 Td (5.  Presets and Saved Searches        p. 45) Tj
0 -18 Td (6.  Exporting Results to CSV          p. 48) Tj
0 -18 Td (7.  Support and Data Requests         p. 50) Tj
0 -18 Td (8.  Keyboard Shortcuts                p. 52) Tj
ET
endstream endobj
5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj
xref 0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000266 00000 n 
0000000998 00000 n 
trailer<</Size 6/Root 1 0 R>>
startxref 1087
%%EOF`;

  const blob = new Blob([content], { type: 'application/pdf' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'ShipInfo-UserManual.pdf';
  a.click();
  URL.revokeObjectURL(url);
}
