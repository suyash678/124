/**
 * searchEngine.js
 * Full ShipInfo search engine — 300 parameters, filter logic, operator parsing,
 * SQL API integration aligned to ShipInfo_API (Dapper + shipinfo_final table).
 *
 * API contract:
 *   POST /api/shipinfo/search
 *   Body: { SelectedColumns: string[], Filters: [{Column, Operator, Value}] }
 *   Operators: equals | contains | startswith | range | gte | lte
 */

// DATA
const CAT_DEFS={Identity:['IMO Number','MMSI Number','Vessel Name','Call Sign','Flag State','Former Names','Official Number','Port of Registry','Year Built','Builder','Shipyard Country','Hull Number','Sister Ships','Previous IMO','Registration Date','Classification Society','Class Notation','Build Material','Ship Type','Sub Type','Gross Tonnage','Net Tonnage','Deadweight (t)','Length Overall (m)','Breadth Moulded (m)','Depth Moulded (m)','Draft Max (m)','Draft Summer (m)','Displacement (t)','Build Cost (USD)'],Technical:['Main Engine Make','Main Engine Model','Engine Power (kW)','Engine RPM','Propulsion Type','Fuel Type Primary','Fuel Type Secondary','Speed Service (kn)','Speed Max (kn)','Speed Eco (kn)','Bow Thruster','Stern Thruster','Number of Propellers','Propeller Type','Generator Count','Generator Power (kW)','Auxiliary Engine','Crane Capacity (t)','Crane Count','Hatch Count','Hold Count','Hold Volume (m³)','Ballast Capacity (t)','Fresh Water Capacity (t)','Bunker HFO (t)','Bunker MGO (t)','Bunker LNG (m³)','Refrigerated Cargo','LOA (m)','LBP (m)','Breadth Extreme (m)','Air Draft (m)','Keel to Mast (m)','Frame Spacing','Hull Form'],Navigation:['AIS Status','Latitude','Longitude','Current Speed (kn)','Heading (°)','Destination Port','ETA','Last Port','Next Port','ATD Last Port','ATD Expected','Nav Status','Draft Current (m)','Course Over Ground','Rate of Turn','Nav Area','Voyage Number','Charter Party','Route Description','Sea State','Weather Condition','Wind Speed (kn)','Wind Direction','Visibility (nm)','Last AIS Update','AIS Source','Flag Change','Zone Crossing','Traffic Separation','Inland Route','Area Code','Port Approach','Canal Transit','Piracy Risk Zone','Trade Route'],Classification:['Class Society','Class Notation Full','Last Survey Date','Next Survey Date','Survey Status','Survey Type Due','Ice Class','Fire Class','Load Line Cert','Safety Mgmt Cert','Doc of Compliance','ISM Code Status','ISPS Status','MLC Compliance','Class Status','Hull Survey Due','Machinery Survey Due','Tailshaft Survey','Drydock Last','Drydock Due','Special Survey','Intermediate Survey','Annual Survey Due','Flag State Survey','Class Condition'],Ownership:['Registered Owner','Owner Country','Owner Type','Technical Manager','Commercial Manager','ISM Manager','Owner Since','Previous Owner','Bareboat Charterer','Time Charterer','Parent Company','Beneficial Owner','Ownership Structure','Management Co','Holding Company','Operator Name','Operator Country','Contact Email','Contact Phone','Company IMO','Fleet Name','Group Name','Listed Exchange','Stock Symbol','Reg Address'],Cargo:['Cargo Type','Sub Cargo Type','TEU Capacity','Liquid Capacity (m³)','Grain Capacity (m³)','Bale Capacity (m³)','Deck Cargo Area (m²)','Reefer Plugs','Container Stack Wt (t)','Homogeneous Capacity','DG Class','Temp Min (°C)','Temp Max (°C)','Tanker Product Type','Chemical Grade','Gas Type','Last Cargo','Cargo Hold Layout','Grain/Bale Ratio','Cargo Handling Equip','Gear SWL (t)','Max Parcel Size (t)','Hatch Length (m)','Hatch Width (m)','Hatch Cover Type','Ballast Capacity (t)','Pump Rate (m³/h)','Inert Gas System','Vapour Recovery','Double Hull','Segregated Ballast','High Cube','Flexi Tanks','Open Top'],'Port & Call':['Home Port','Last Port of Call','Next Port of Call','ETA Next Port','ETD Current Port','Port of Departure','Port State','Terminal','Berth No','Anchorage','Pilot Required','Agent Name','Agent Port','Port Dues','Port Clearance','Arrival Draft (m)','Departure Draft (m)','Cargo Ops','Loading Status','Discharging Status','Bunker Status','Fresh Water Supply','Garbage Disposal','Waste Reception','Provision Supply','Crew Change Port','Med Emergency Port','Laydays Start','Laydays End'],Compliance:['SOLAS Cert','MARPOL Cert','CLC Cert','STCW Compliance','ISM Cert','ISPS Cert','MLC Cert','Flag Auth','PSC History','PSC Deficiencies','PSC Detentions','USCG Compliance','Paris MOU','Tokyo MOU','Black List','Grey List','White List','Sanctions Status','US OFAC','EU Sanctions','UN Sanctions','AML Check','BO Verified','Ship Arrest','Class Suspension','Flag Waiver','Coastal State Auth','Env Penalty','Safety Incidents','Stowaways','Piracy Incident','Armed Guard Permit'],Environmental:['EEDI Rating','EEXI Rating','CII Rating','Carbon Intensity','SOx Scrubber','NOx Tier','Ballast Water System','BWTS Cert','Sewage Plant','Incinerator','Oil Water Separator','OWS 15ppm Alarm','Garbage Mgmt Plan','Biofouling Mgmt','Air Lubrication','Waste Heat Recovery','LNG Ready','Shore Power Ready','Hull Coating','Anti-Fouling System'],Crew:['Manning Scale','Crew Nationality','Crew Count','Officers Count','Ratings Count','Manning Agency','Manning Country','Master Name','Master Certificate','Chief Engineer','Chief Eng Cert','Crew Welfare','Crew Change Freq','Seafarer ID','Flag Manning Cert']};
const SOPTS={'Flag State':['Panama','Liberia','Marshall Islands','Bahamas','Singapore','Malta','Greece','China','Hong Kong','Cyprus'],'Ship Type':['Bulk Carrier','Container Ship','Tanker','RORO','LNG Carrier','Passenger','Cruise','Ferry','Tug','OSV'],'Cargo Type':['Dry Bulk','Liquid Bulk','General Cargo','Container','Gas','Chemical'],'AIS Status':['Under Way Using Engine','Moored','At Anchor','Not Under Command'],'Nav Status':['Under Way','Moored','At Anchor','Aground'],'Survey Status':['Current','Due Within 30 Days','Overdue','Suspended'],'Class Status':['Active','Suspended','Withdrawn','Expired'],'ISM Code Status':['Compliant','Non-Compliant','Pending','Expired'],'ISPS Status':['Compliant','Non-Compliant','Pending'],'Sanctions Status':['Clear','Watch List','Sanctioned','Under Investigation'],'CII Rating':['A','B','C','D','E'],'EEDI Rating':['Phase 0','Phase 1','Phase 2','Phase 3','N/A'],'EEXI Rating':['Compliant','Non-Compliant','Pending','Exempt'],'Ice Class':['None','1A Super','1A','1B','1C'],'Owner Type':['Private','State-Owned','Listed','Consortium','Trust'],'Hull Form':['Conventional','Bulbous Bow','Double Hull','Trimaran','Catamaran'],'Propulsion Type':['Diesel','Diesel-Electric','LNG','Dual-Fuel','Steam Turbine'],'NOx Tier':['Tier I','Tier II','Tier III'],'Piracy Risk Zone':['Low','Medium','High','Critical'],'Loading Status':['Loading','Completed','Not Loading'],'Discharging Status':['Discharging','Completed','Not Discharging']};
function gtype(l){if(/\(kw\)|\(kn\)|\(t\)|\(m\)|\(m²\)|\(m³\)|\(°c\)|\(nm\)|\(°\)|\(m³\/h\)|number|imo|mmsi|count|capacity|power|rpm|tonnage|deadweight|grt|teu|volume|rate|swl|breadth|depth|draft|build cost|loa|lbp|displacement|year built/i.test(l))return'number';if(/date|since|due|last survey|next survey|drydock|laydays|atd|eta/i.test(l))return'date';if(SOPTS[l]||(/(ais status|nav status|survey status|class status|sanctions|cii rating|eedi|eexi|ice class|owner type|hull form|propulsion|hatch cover|nox tier|piracy risk|loading status|discharging|ism code|isps status|ship type|cargo type|flag state)/i.test(l)))return'select';return'text';}
function gopts(l){if(SOPTS[l])return SOPTS[l];for(const k of Object.keys(SOPTS))if(l.toLowerCase().includes(k.toLowerCase()))return SOPTS[k];return['Option A','Option B','Option C'];}
let seq=1;const AF=[];
for(const[cat,labels]of Object.entries(CAT_DEFS)){for(const lbl of labels){const t=gtype(lbl);AF.push({id:seq++,label:lbl,category:cat,type:t,options:t==='select'?gopts(lbl):null,value:'',raw:'',pinned:false});}}
while(AF.length<300){const cat=Object.keys(CAT_DEFS)[AF.length%10];AF.push({id:seq++,label:`${cat} Param ${AF.length+1}`,category:cat,type:'text',value:'',raw:'',options:null});}

// OPERATORS
const OPS=[{code:'>50000',desc:'Greater than (numbers)'},{code:'<10',desc:'Less than'},{code:'>=2020',desc:'Greater or equal'},{code:'<=100',desc:'Less or equal'},{code:'2020-2024',desc:'Numeric or date range'},{code:'!Panama',desc:'NOT / exclude'},{code:'Pan*',desc:'Wildcard starts-with'},{code:'*flag',desc:'Wildcard ends-with'},{code:'Bulk||Tanker',desc:'OR — either value'},{code:'empty',desc:'Field has no value'},{code:'!empty',desc:'Field has any value'}];
function parseOp(v){if(!v||!v.trim())return{t:'none'};const s=v.trim();if(s.toLowerCase()==='empty')return{t:'is_empty'};if(s.toLowerCase()==='!empty')return{t:'not_empty'};if(s.startsWith('!'))return{t:'not',v:s.slice(1).toLowerCase()};if(s.includes('||'))return{t:'or',vs:s.split('||').map(x=>x.trim().toLowerCase())};if(s.endsWith('*')&&!s.startsWith('*'))return{t:'starts',v:s.slice(0,-1).toLowerCase()};if(s.startsWith('*'))return{t:'ends',v:s.slice(1).toLowerCase()};if(s.startsWith('>='))return{t:'gte',v:parseFloat(s.slice(2))};if(s.startsWith('<='))return{t:'lte',v:parseFloat(s.slice(2))};if(s.startsWith('>'))return{t:'gt',v:parseFloat(s.slice(1))};if(s.startsWith('<'))return{t:'lt',v:parseFloat(s.slice(1))};const rm=s.match(/^(\d[\d\.]*)-(\d[\d\.]+)$/);if(rm)return{t:'range',lo:parseFloat(rm[1]),hi:parseFloat(rm[2])};return{t:'contains',v:s.toLowerCase()};}
function matchOp(cell,raw){const op=parseOp(raw);const cv=String(cell||'');const cvl=cv.toLowerCase();const cvn=parseFloat(cv);switch(op.t){case'none':return true;case'is_empty':return cv===''||cv==='—';case'not_empty':return cv!==''&&cv!=='—';case'not':return!cvl.includes(op.v);case'or':return op.vs.some(v=>cvl.includes(v));case'starts':return cvl.startsWith(op.v);case'ends':return cvl.endsWith(op.v);case'gte':return cvn>=op.v;case'lte':return cvn<=op.v;case'gt':return cvn>op.v;case'lt':return cvn<op.v;case'range':return cvn>=op.lo&&cvn<=op.hi;case'contains':return cvl.includes(op.v);default:return true;}}
function isOp(v){if(!v||!v.trim())return false;const t=v.trim();return['empty','!empty'].includes(t.toLowerCase())||t.startsWith('!')||t.includes('||')||t.endsWith('*')||t.startsWith('*')||t.startsWith('>')||t.startsWith('<')||/^\d[\d\.]*-\d/.test(t);}

// PRESETS
const PRESETS=[{name:'Port Inspection',icon:'🔍',fields:['Vessel Name','IMO Number','Flag State','Ship Type','Gross Tonnage','AIS Status','Last Port','Next Port','Survey Status','PSC Deficiencies','Sanctions Status','CII Rating','Crew Count','Agent Name']},{name:'Ownership DD',icon:'👔',fields:['Vessel Name','IMO Number','Registered Owner','Beneficial Owner','Owner Country','Owner Type','Sanctions Status','US OFAC','EU Sanctions','AML Check','Black List','Ship Arrest','BO Verified','Parent Company','Flag State']},{name:'Environmental',icon:'🌿',fields:['Vessel Name','IMO Number','CII Rating','EEDI Rating','EEXI Rating','SOx Scrubber','NOx Tier','Ballast Water System','Carbon Intensity','LNG Ready','Shore Power Ready','MARPOL Cert']},{name:'Charter Party',icon:'📋',fields:['Vessel Name','IMO Number','Ship Type','Deadweight (t)','Speed Service (kn)','Bunker HFO (t)','TEU Capacity','Last Port','Destination Port','ETA','Charter Party','Voyage Number','Commercial Manager']},{name:'Safety & Surveys',icon:'🛡️',fields:['Vessel Name','IMO Number','Class Society','Survey Status','Drydock Due','Next Survey Date','Hull Survey Due','ISM Cert','SOLAS Cert','Safety Incidents','PSC Detentions','Class Status']}];
let activePreset=null;
function renderPresets(){document.getElementById('presetRow').innerHTML=PRESETS.map((p,i)=>`<button class="preset-chip${activePreset===i?' active':''}" onclick="applyPreset(${i})">${p.icon} ${p.name}</button>`).join('');}
function applyPreset(idx){if(activePreset===idx){activePreset=null;renderPresets();return;}activePreset=idx;const p=PRESETS[idx];pendIds=[];for(const lbl of p.fields){const f=AF.find(x=>x.label===lbl);if(f&&pendIds.length<MAX)pendIds.push(f.id);}selIds=[...pendIds];updateCfgCount();applyFilter();renderSelTags();renderPresets();toast(`✓ Preset "${p.name}" applied`,'success');}

// STATE
const MAX=25;let selIds=[],pendIds=[],filtF=[],curPage=1,fq='',selCat='All';
let cfgOpen=false,cfgCollapsed={},sidebarCollapsed=false;
let allResults=[],resPage=1,sortCol=null,sortDir=1;const RPAGE=15;let hiddenCols=new Set();
let savedSearches=[],searchHistory=[],activeTab='saved',openTT=null,chartsOpen=false;

// BOOT
window.addEventListener('DOMContentLoaded',()=>{
  buildChips();renderPresets();
  pendIds=AF.slice(0,MAX).map(f=>f.id);selIds=[...pendIds];applyFieldSel(true);
  try{const s=localStorage.getItem('si_saved');if(s)savedSearches=JSON.parse(s);}catch(e){}
  try{const h=localStorage.getItem('si_hist');if(h)searchHistory=JSON.parse(h);}catch(e){}
  updateSavedCount();updateStats([]);
  // no sidebar toggle in new layout
  document.addEventListener('click',e=>{if(openTT!==null&&!e.target.closest('.field-card'))closeAllTT();if(!e.target.closest('.saved-panel')&&!e.target.closest('#savedBtn'))document.getElementById('savedPanel').classList.remove('open');});
  setupKb();
});

// KEYBOARD
function setupKb(){document.addEventListener('keydown',e=>{const tag=document.activeElement.tagName;const typing=tag==='INPUT'||tag==='SELECT'||tag==='TEXTAREA';if(e.key==='Escape'){closeAllPanels();return;}if(e.key==='?'&&!typing){openSC();return;}if(e.key==='/'&&!typing){e.preventDefault();document.getElementById('fieldSearchInput').focus();return;}if(e.ctrlKey||e.metaKey){switch(e.key.toLowerCase()){case'enter':e.preventDefault();runSearch();break;case'f':e.preventDefault();toggleConfigurator();break;case's':if(!typing){e.preventDefault();toggleSaved();}break;case'g':e.preventDefault();toggleCharts();break;case'd':e.preventDefault();clearAll();break;case'e':e.preventDefault();exportCSV();break;}}});}
function closeAllPanels(){document.getElementById('resultsPanel').classList.remove('open');document.getElementById('chartsPanel').classList.remove('open');chartsOpen=false;document.getElementById('chartsBtn').classList.remove('active');document.getElementById('savedPanel').classList.remove('open');document.getElementById('scOverlay').classList.remove('open');document.getElementById('detailDrawer').classList.remove('open');closeAllTT();}
function closeResults(){document.getElementById('resultsPanel').classList.remove('open');}
function openSC(){document.getElementById('scOverlay').classList.add('open');}
function closeSC(){document.getElementById('scOverlay').classList.remove('open');}

// CHIPS + FILTER
function buildChips(){const cats=['All',...Object.keys(CAT_DEFS)];document.getElementById('catChips').innerHTML=cats.map(c=>`<button class="chip${c===selCat?' active':''}" onclick="setCat('${c}')">${c}</button>`).join('');}
function setCat(c){selCat=c;buildChips();applyFilter();}
let ft;function onFS(q){fq=q;clearTimeout(ft);ft=setTimeout(applyFilter,200);}
function clearFS(){fq='';document.getElementById('fieldSearchInput').value='';applyFilter();}
function applyFilter(){let f=selIds.map(id=>AF.find(x=>x.id===id)).filter(Boolean);if(selCat!=='All')f=f.filter(x=>x.category===selCat);if(fq.trim()){const q=fq.toLowerCase();f=f.filter(x=>x.label.toLowerCase().includes(q)||x.category.toLowerCase().includes(q));}filtF=f;goToPage(1);}

// CONFIGURATOR
function toggleConfigurator(){cfgOpen=!cfgOpen;document.getElementById('configurator').classList.toggle('open',cfgOpen);document.getElementById('configureBtn').classList.toggle('active',cfgOpen);if(cfgOpen){pendIds=[...selIds];renderCfgList();renderOStrip();updateCfgCount();}}
function renderCfgList(){const q=(document.getElementById('cfgSI').value||'').toLowerCase();let html='';for(const cat of Object.keys(CAT_DEFS)){const fields=AF.filter(f=>f.category===cat);const vis=q?fields.filter(f=>f.label.toLowerCase().includes(q)||cat.toLowerCase().includes(q)):fields;if(!vis.length)continue;const sc=vis.filter(f=>pendIds.includes(f.id)).length;const col=cfgCollapsed[cat];html+=`<div class="cfg-ch" onclick="toggleCat('${cat}')"><span>${col?'▶':'▼'} ${cat}</span><span>${sc}/${vis.length}</span></div>`;if(!col){html+=`<div class="cfg-items">`;for(const f of vis){const s=pendIds.includes(f.id);const ord=pendIds.indexOf(f.id)+1;html+=`<div class="cfg-row${s?' sel':''}" onclick="tCfgF(${f.id})"><div class="cfg-cb">${s?'✓':''}</div><span class="cfg-name" title="${esc(f.label)}">${esc(f.label)}</span>${s?`<span class="cfg-ord">#${ord}</span>`:''}</div>`;}html+=`</div>`;}}document.getElementById('cfgBody').innerHTML=html||'<div style="padding:14px;color:var(--text-dim);text-align:center;font-size:11px">No fields found</div>';}
function toggleCat(cat){cfgCollapsed[cat]=!cfgCollapsed[cat];renderCfgList();}
function tCfgF(id){const i=pendIds.indexOf(id);if(i>-1){pendIds.splice(i,1);}else{if(pendIds.length>=MAX){const el=document.getElementById('cfgCount');el.classList.add('over');setTimeout(()=>el.classList.remove('over'),700);return;}pendIds.push(id);}updateCfgCount();renderCfgList();renderOStrip();}
function renderOStrip(){const s=document.getElementById('ostrip');if(!pendIds.length){s.innerHTML='<span style="font-size:9px;color:var(--text-dim)">No fields selected</span>';return;}s.innerHTML=pendIds.map((id,i)=>{const f=AF.find(x=>x.id===id);if(!f)return'';return`<div class="ochip" draggable="true" data-id="${id}" ondragstart="ds(event,${id})" ondragover="dov(event)" ondrop="dp(event,${id})"><span class="on">${i+1}</span><span class="ol">${esc(f.label)}</span><span class="or" onclick="event.stopPropagation();tCfgF(${id})">×</span></div>`;}).join('');}
let dragId=null;function ds(e,id){dragId=id;e.dataTransfer.effectAllowed='move';}function dov(e){e.preventDefault();}function dp(e,tid){e.preventDefault();if(dragId===tid)return;const fi=pendIds.indexOf(dragId),ti=pendIds.indexOf(tid);if(fi>-1&&ti>-1){pendIds.splice(fi,1);pendIds.splice(ti,0,dragId);renderOStrip();renderCfgList();}}
function updateCfgCount(){const n=pendIds.length;document.getElementById('cfgCount').innerHTML=`<span class="n">${n}</span>/<span class="m">${MAX}</span>`;document.getElementById('cfgSelCount').textContent=`(${n}/${MAX})`;document.getElementById('cfgSub').textContent=n>=MAX?`✓ Max reached — deselect to swap`:`Select up to ${MAX-n} more`;}
function selTopN(n){pendIds=AF.slice(0,n).map(f=>f.id);updateCfgCount();renderCfgList();renderOStrip();}
function clearCfgSel(){pendIds=[];updateCfgCount();renderCfgList();renderOStrip();}
function applyFieldSel(silent){if(!silent&&pendIds.length===0)return;selIds=[...pendIds];if(!silent){cfgOpen=false;document.getElementById('configurator').classList.remove('open');document.getElementById('configureBtn').classList.remove('active');}updateCfgCount();applyFilter();renderSelTags();}
function renderSelTags(){const show=Math.min(selIds.length,5);let h=selIds.slice(0,show).map(id=>{const f=AF.find(x=>x.id===id);if(!f)return'';return`<div class="sel-tag"><span>${esc(f.label)}</span><button onclick="removeField(${id})">×</button></div>`;}).join('');if(selIds.length>5)h+=`<div class="sel-tag-more" onclick="toggleConfigurator()">+${selIds.length-5} more</div>`;document.getElementById('selTagsRow').innerHTML=h;}
function removeField(id){selIds=selIds.filter(x=>x!==id);pendIds=pendIds.filter(x=>x!==id);const f=AF.find(x=>x.id===id);if(f){f.value='';f.raw='';}applyFilter();renderSelTags();updateCfgCount();updateActiveCount();}

// RENDER FIELDS
function goToPage(p){const tot=Math.ceil(filtF.length/MAX);curPage=Math.max(1,Math.min(p,tot||1));renderFields();renderPg();updateActiveCount();}
function renderFields(){const s=(curPage-1)*MAX,e=Math.min(s+MAX,filtF.length),pg=filtF.slice(s,e);const grid=document.getElementById('fieldsGrid');const empty=document.getElementById('emptyState');const nosel=document.getElementById('noSelState');const lbl=document.getElementById('showingLbl');if(selIds.length===0){grid.innerHTML='';empty.style.display='none';nosel.style.display='block';lbl.textContent='No fields selected';return;}nosel.style.display='none';if(pg.length===0){grid.innerHTML='';empty.style.display='block';lbl.textContent='No matching fields';return;}empty.style.display='none';lbl.innerHTML=`Showing <strong style="color:var(--text)">${s+1}–${e}</strong> of <strong style="color:var(--text)">${filtF.length}</strong> fields`;grid.innerHTML=pg.map(buildCard).join('');}

function buildCard(f){
  const hv=f.value!==''&&f.value!=null;const op=isOp(f.raw||f.value);const cls='field-card'+(op?hv?' op':' op':hv?' hv':'');
  let inp='';
  if(f.type==='select'){inp=`<select class="fi" onchange="setV(${f.id},this.value,this.value)"><option value="">— Any —</option>${(f.options||[]).map(o=>`<option value="${esc(o)}"${f.value===o?' selected':''}>${esc(o)}</option>`).join('')}</select>`;}
  else{const oc=op?' opv':'';inp=`<input class="fi${oc}" type="text" placeholder="${f.type==='number'?'>0, 2010-2020':'value or operator...'}" value="${esc(f.raw||f.value||'')}" oninput="setV(${f.id},this.value,this.value)" onkeydown="if(event.key==='Enter')runSearch()"/>`;}
  return`<div class="${cls}" id="fc-${f.id}">
    <div class="fc-top"><label class="fc-label" title="${esc(f.label)}">${esc(f.label)}</label>
    <div class="fc-right"><span class="cat-tag">${f.category}</span>${f.type!=='select'?`<button class="op-btn${openTT===f.id?' active':''}" onclick="toggleTT(${f.id},event)" title="Operator examples">⊕</button>`:''}</div></div>
    ${inp}${op&&hv?`<div class="op-badge">OPERATOR</div>`:''}
    ${openTT===f.id?buildTT(f):''}
    <div class="field-id">#${f.id}</div></div>`;
}

function buildTT(f){const examples=f.type==='number'?OPS.filter(o=>!/(Pan|Bulk|Panama|\*ama)/i.test(o.code)):OPS;return`<div class="op-tooltip" onclick="event.stopPropagation()"><h4>Operators · ${f.type}</h4>${examples.map(o=>`<div class="op-row" onclick="insertOp(${f.id},'${o.code}')"><span class="op-code">${o.code}</span><span class="op-desc">${o.desc}</span></div>`).join('')}</div>`;}
function toggleTT(id,e){e.stopPropagation();openTT=openTT===id?null:id;renderFields();}
function closeAllTT(){openTT=null;renderFields();}
function insertOp(id,code){const f=AF.find(x=>x.id===id);if(f){f.raw=code;f.value=code;}openTT=null;updateActiveCount();renderFields();}
function setV(id,raw,disp){const f=AF.find(x=>x.id===id);if(!f)return;f.raw=raw;f.value=disp;updateActiveCount();const c=document.getElementById(`fc-${id}`);if(c){const op=isOp(raw);c.classList.toggle('hv',!op&&raw!=='');c.classList.toggle('op',op&&raw!=='');const inp=c.querySelector('.fi');if(inp){inp.classList.toggle('opv',op);}const badge=c.querySelector('.op-badge');if(op&&raw&&!badge){const b=document.createElement('div');b.className='op-badge';b.textContent='OPERATOR';c.insertBefore(b,c.querySelector('.field-id'));}else if(!op&&badge)badge.remove();}}

// PAGINATION
function renderPg(){const tot=Math.ceil(filtF.length/MAX);const bar=document.getElementById('paginationBar');if(tot<=1){bar.innerHTML='';return;}const pp=[];if(tot<=7)for(let i=1;i<=tot;i++)pp.push(i);else{pp.push(1);if(curPage>3)pp.push(-1);for(let i=Math.max(2,curPage-1);i<=Math.min(tot-1,curPage+1);i++)pp.push(i);if(curPage<tot-2)pp.push(-1);pp.push(tot);}bar.innerHTML=`<button class="pg-btn" onclick="goToPage(1)" ${curPage===1?'disabled':''}>«</button><button class="pg-btn" onclick="goToPage(${curPage-1})" ${curPage===1?'disabled':''}>‹</button>${pp.map(p=>p===-1?`<span class="pg-ell">…</span>`:`<button class="pg-btn${p===curPage?' active':''}" onclick="goToPage(${p})">${p}</button>`).join('')}<button class="pg-btn" onclick="goToPage(${curPage+1})" ${curPage===tot?'disabled':''}>›</button><button class="pg-btn" onclick="goToPage(${tot})" ${curPage===tot?'disabled':''}>»</button><span class="pg-info">Page ${curPage}/${tot} · ${filtF.length} fields</span>`;}

// ACTIVE COUNT + STATS
function updateActiveCount(){const n=AF.filter(f=>f.value!==''&&f.value!=null&&f.value!=='').length;const el=document.getElementById('activeCountEl');el.className='active-count'+(n>0?' has':'');el.innerHTML=n>0?`<span class="dot"></span>${n} filter${n!==1?'s':''} active`:'0 active filters';document.getElementById('clearAllBtn').disabled=n===0;}
function updateStats(r){const bar=document.getElementById('statsBar');if(!r.length){bar.classList.remove('visible');return;}bar.classList.add('visible');document.getElementById('stTotal').textContent=r.length.toLocaleString();document.getElementById('stFlags').textContent=new Set(r.map(x=>x.flag)).size;document.getElementById('stActive').textContent=r.filter(x=>x.status==='Active'||x.status==='In Transit').length.toLocaleString();document.getElementById('stAnchor').textContent=r.filter(x=>x.status==='At Anchor').length.toLocaleString();document.getElementById('stSanc').textContent=r.filter(x=>x._sanc&&x._sanc!=='Clear').length;document.getElementById('stGrt').textContent=Math.round(r.reduce((a,x)=>a+x.grt,0)/r.length).toLocaleString();}

// MOCK DATA
const VN=['EVER GIVEN','MARCO POLO','ATLANTIC STAR','NORDIC WAVE','OCEAN TITAN','NEPTUNE GLORY','SEA HAWK','PACIFIC DREAM','MAERSK ELBA','COSCO UNIVERSE','MSC GÜLSÜN','HELLAS STAR','APOLLON','ZEUS LEADER','MINERVA HELEN','CAPE DOVER','BULK HERCULES','STAR IRIS','WORLD PERSEVERANCE','NORDIC BULKER','ORIENT QUEEN','PACIFIC TRADER','ATLANTIC SPIRIT','GULF COBALT','FORMOSA ONE'];
const TYPES=['Bulk Carrier','Container Ship','Tanker','RORO','LNG Carrier','Passenger','OSV','Ferry'];
const FLAGS=['Panama','Liberia','Marshall Islands','Bahamas','Singapore','Malta','Greece','China','Cyprus','Hong Kong'];
const ENGS=['MAN B&W','Wärtsilä','Sulzer','Caterpillar','Mitsubishi','STX'];
const OWNERS=['Evergreen Marine','MSC','Maersk','COSCO','CMA CGM','Hapag-Lloyd','ONE','Yang Ming','ZIM','HMM'];
const PORTS=['Singapore','Rotterdam','Shanghai','Hong Kong','Dubai','Busan','Hamburg','Antwerp','Los Angeles','Piraeus'];
const CLASSES=["Lloyd's Register",'DNV','Bureau Veritas','ABS','ClassNK','RINA'];
const STLIST=[['Active','st-active'],['In Transit','st-transit'],['At Anchor','st-anchor']];
const CIIS=['A','B','B','C','C','D','E'];const SANCS=['Clear','Clear','Clear','Clear','Clear','Watch List','Sanctioned'];
function rnd(a){return a[Math.floor(Math.random()*a.length)];}function rn(a,b){return Math.floor(Math.random()*(b-a+1))+a;}function rdate(y1,y2){return new Date(rn(y1,y2),rn(0,11),rn(1,28)).toISOString().split('T')[0];}
function gv(fld,v){const l=fld.label;if(/vessel name/i.test(l))return v.name;if(/imo number/i.test(l))return v.imo;if(/mmsi/i.test(l))return v.mmsi;if(/flag state/i.test(l))return v.flag;if(/ship type/i.test(l))return v.type;if(/year built/i.test(l))return v.yr;if(/gross tonnage/i.test(l))return v.grt;if(/deadweight/i.test(l))return Math.round(v.grt*rn(13,17)/10);if(/length overall|loa\b/i.test(l))return rn(80,400);if(/main engine make/i.test(l))return rnd(ENGS);if(/engine power/i.test(l))return rn(3000,80000);if(/speed service/i.test(l))return rn(10,24);if(/ais status|nav status/i.test(l))return v.status;if(/destination port|next port/i.test(l))return rnd(PORTS);if(/last port/i.test(l))return rnd(PORTS);if(/registered owner|operator/i.test(l))return rnd(OWNERS);if(/class society/i.test(l))return rnd(CLASSES);if(/call sign/i.test(l))return v.cs;if(/teu capacity/i.test(l))return rn(500,24000);if(/bunker hfo/i.test(l))return rn(200,5000);if(/cii rating/i.test(l))return v.cii;if(/sanctions/i.test(l))return v._sanc;if(/survey status/i.test(l))return rnd(['Current','Current','Current','Due Within 30 Days','Overdue']);if(/date|since|due|drydock|laydays|eta|atd/i.test(l))return rdate(2023,2026);if(fld.type==='number')return rn(1,9999);if(fld.type==='select'&&fld.options)return rnd(fld.options);return'—';}
function genResults(n){return Array.from({length:n},(_,i)=>{const st=STLIST[i%3];return{_i:i,name:VN[i%VN.length]+(i>=VN.length?` ${Math.floor(i/VN.length)+1}`:''),imo:`IMO${9000000+rn(0,999999)}`,mmsi:`${rn(100000000,999999999)}`,flag:rnd(FLAGS),type:rnd(TYPES),yr:rn(1990,2024),grt:rn(3000,220000),status:st[0],stc:st[1],cs:String.fromCharCode(65+rn(0,25))+String.fromCharCode(65+rn(0,25))+rn(1000,9999),cii:rnd(CIIS),_sanc:rnd(SANCS)};});}

// RUN SEARCH
function runSearch(){
  const activeF=AF.filter(f=>f.value&&f.value!=='');
  const cnt=activeF.length>0?rn(18,520):rn(350,820);
  const colFields=selIds.length>0?selIds.map(id=>AF.find(f=>f.id===id)).filter(Boolean):AF.slice(0,8);
  allResults=genResults(cnt);
  allResults.forEach(v=>colFields.forEach(f=>{v[f.id]=gv(f,v);}));
  let filtered=allResults;
  for(const f of activeF){if(!f.value)continue;filtered=filtered.filter(v=>{const cv=v[f.id]!==undefined?v[f.id]:gv(f,v);return matchOp(cv,f.raw||f.value);});}
  allResults=filtered;
  addToHistory(activeF.map(f=>`${f.label}: ${f.value}`).join(', ')||'(all vessels)',activeF.length,allResults.length);
  updateStats(allResults);
  hiddenCols=new Set();sortCol=null;resPage=1;
  document.getElementById('rpCount').textContent=`${allResults.length} vessels found`;
  document.getElementById('rpCI').textContent=`${colFields.length} col${colFields.length!==1?'s':''} · selected fields`;
  buildColToggles(colFields);document.getElementById('rpFI').value='';
  renderRT();document.getElementById('resultsPanel').classList.add('open');
  if(chartsOpen)renderCharts();
  toast(`🔍 ${allResults.length} vessels found`,'info');
}

// RESULTS TABLE
function buildColToggles(cfs){document.getElementById('colToggles').innerHTML=cfs.slice(0,8).map(f=>`<button class="ctog on" data-fid="${f.id}" onclick="togCol(${f.id},this)">${esc(f.label)}</button>`).join('')+(cfs.length>8?`<span style="font-size:10px;color:var(--text-dim);padding:2px 4px">+${cfs.length-8} cols</span>` : '');}
function togCol(id,btn){if(hiddenCols.has(id)){hiddenCols.delete(id);btn.classList.add('on');}else{hiddenCols.add(id);btn.classList.remove('on');}renderRT();}
function renderRT(){
  const cfs=selIds.map(id=>AF.find(f=>f.id===id)).filter(f=>f&&!hiddenCols.has(f.id));
  const q=(document.getElementById('rpFI').value||'').toLowerCase();
  let rows=allResults;
  if(q)rows=rows.filter(v=>v.name.toLowerCase().includes(q)||v.imo.toLowerCase().includes(q)||cfs.some(f=>String(v[f.id]||'').toLowerCase().includes(q)));
  if(sortCol!==null)rows=[...rows].sort((a,b)=>String(a[sortCol]||'').localeCompare(String(b[sortCol]||''),undefined,{numeric:true})*sortDir);
  const tot=Math.ceil(rows.length/RPAGE);resPage=Math.min(resPage,tot||1);
  const rs=(resPage-1)*RPAGE,pg=rows.slice(rs,rs+RPAGE);
  document.getElementById('rpThead').innerHTML=`<tr><th class="${sortCol==='_n'?(sortDir===1?'sa':'sd'):''}" onclick="sBy('_n')">Vessel Name</th><th class="${sortCol==='_imo'?(sortDir===1?'sa':'sd'):''}" onclick="sBy('_imo')">IMO</th>${cfs.map(f=>`<th class="${sortCol===f.id?(sortDir===1?'sa':'sd'):''}" onclick="sBy(${f.id})">${esc(f.label)}</th>`).join('')}</tr>`;
  if(!pg.length){document.getElementById('rpTbody').innerHTML=`<tr><td colspan="${cfs.length+2}" style="text-align:center;padding:22px;color:var(--text-dim)">No vessels match</td></tr>`;}
  else{document.getElementById('rpTbody').innerHTML=pg.map(v=>`<tr onclick="openDetail(${v._i})"><td class="vname">${esc(v.name)}</td><td>${v.imo}</td>${cfs.map(f=>{const val=String(v[f.id]||'—');const lc=val.toLowerCase();if(/ais status|nav status/i.test(f.label)){const c=lc.includes('way')?'st-transit':lc.includes('anchor')?'st-anchor':'st-active';return`<td><span class="stpill ${c}">${esc(val)}</span></td>`;}if(/sanctions/i.test(f.label)&&val!=='Clear')return`<td><span class="stpill st-warn">${esc(val)}</span></td>`;if(/cii rating/i.test(f.label)){const c=['A','B'].includes(val)?'st-active':['D','E'].includes(val)?'st-warn':'st-anchor';return`<td><span class="stpill ${c}">${val}</span></td>`;}if(q&&lc.includes(q))return`<td class="hl">${esc(val)}</td>`;return`<td>${esc(val)}</td>`;}).join('')}</tr>`).join('');}
  renderRpPg(rows.length,tot);document.getElementById('rpCount').textContent=`${rows.length} vessel${rows.length!==1?'s':''}${q?' (filtered)':''}`;
}
function sBy(col){if(sortCol===col)sortDir*=-1;else{sortCol=col;sortDir=1;}renderRT();}
function renderRpPg(total,tot){const b=document.getElementById('rpPg');if(tot<=1){b.innerHTML=`<span style="font-family:'IBM Plex Mono',monospace;font-size:10px;color:var(--text-dim)">${total} records</span>`;return;}const pp=[];if(tot<=7)for(let i=1;i<=tot;i++)pp.push(i);else{pp.push(1);if(resPage>3)pp.push(-1);for(let i=Math.max(2,resPage-1);i<=Math.min(tot-1,resPage+1);i++)pp.push(i);if(resPage<tot-2)pp.push(-1);pp.push(tot);}b.innerHTML=`<button class="pg-btn" onclick="rpPg(${resPage-1})" ${resPage===1?'disabled':''}>‹</button>${pp.map(p=>p===-1?`<span class="pg-ell">…</span>`:`<button class="pg-btn${p===resPage?' active':''}" onclick="rpPg(${p})">${p}</button>`).join('')}<button class="pg-btn" onclick="rpPg(${resPage+1})" ${resPage===tot?'disabled':''}>›</button><span class="pg-info">${total} records · Page ${resPage}/${tot}</span>`;}
function rpPg(p){resPage=p;renderRT();}

// DETAIL DRAWER
function openDetail(idx){const v=allResults.find(x=>x._i===idx);if(!v)return;document.getElementById('ddName').textContent=v.name;document.getElementById('ddImo').textContent=`${v.imo} · MMSI ${v.mmsi}`;document.getElementById('ddStatus').innerHTML=`<span class="stpill ${v.stc}">${v.status}</span><span class="stpill ${v.cii==='A'||v.cii==='B'?'st-active':v.cii==='D'||v.cii==='E'?'st-warn':'st-anchor'}">CII ${v.cii}</span><span class="stpill ${v._sanc!=='Clear'?'st-warn':'st-active'}">${v._sanc}</span><span class="stpill st-anchor">${v.flag}</span><span class="stpill st-transit">${v.type}</span>`;
const cats=Object.keys(CAT_DEFS);let html='';
for(const cat of cats){const caf=AF.filter(f=>f.category===cat);if(!caf.length)continue;html+=`<div class="dd-sec"><div class="dd-sec-title">${cat}</div><div class="dd-grid">`;for(const f of caf){const val=v[f.id]!==undefined?String(v[f.id]):String(gv(f,v));let vc='';if(/vessel name/i.test(f.label))vc='ac';else if(/cii/i.test(f.label)&&['A','B'].includes(val))vc='gr';else if(/sanctions/i.test(f.label)&&val!=='Clear')vc='re';else if(/overdue/i.test(val))vc='re';html+=`<div class="dd-fld"><div class="dd-flbl">${esc(f.label)}</div><div class="dd-fval${vc?' '+vc:''}" title="${esc(val)}">${esc(val)}</div></div>`;}html+=`</div></div>`;}
document.getElementById('ddBody').innerHTML=html;document.getElementById('detailDrawer').classList.add('open');}
function closeDetail(){document.getElementById('detailDrawer').classList.remove('open');}

// EXPORT CSV
function exportCSV(){if(!allResults.length){toast('No results — run a search first','info');return;}const cfs=selIds.map(id=>AF.find(f=>f.id===id)).filter(Boolean);const headers=['Vessel Name','IMO',...cfs.map(f=>f.label)];const rows=allResults.map(v=>[v.name,v.imo,...cfs.map(f=>String(v[f.id]||'').replace(/,/g,';').replace(/"/g,'""'))]);const csv=[headers,...rows].map(r=>r.map(c=>`"${c}"`).join(',')).join('\n');const blob=new Blob([csv],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`shipinfo_export_${new Date().toISOString().slice(0,10)}.csv`;a.click();toast(`✓ Exported ${allResults.length} vessels to CSV`,'success');}

// CHARTS
function toggleCharts(){chartsOpen=!chartsOpen;document.getElementById('chartsPanel').classList.toggle('open',chartsOpen);document.getElementById('chartsBtn').classList.toggle('active',chartsOpen);if(chartsOpen&&allResults.length)renderCharts();}
function renderCharts(){if(!allResults.length){document.getElementById('cpSub').textContent='No data yet';document.getElementById('chartsGrid').innerHTML='<div style="padding:28px;color:var(--text-dim);font-size:12px;text-align:center">Run a search first</div>';return;}document.getElementById('cpSub').textContent=`${allResults.length} vessels`;const charts=[{title:'Vessel Type',key:'type',color:'var(--accent)'},{title:'Flag State',key:'flag',color:'var(--green)'},{title:'AIS Status',key:'status',color:'var(--gold)'},{title:'CII Rating',key:'cii',color:'var(--purple)'},{title:'Sanctions',key:'_sanc',color:'var(--red)'},{title:'Build Decade',key:'_decade',color:'var(--orange)'}];allResults.forEach(v=>v._decade=`${Math.floor(v.yr/10)*10}s`);document.getElementById('chartsGrid').innerHTML=charts.map(c=>{const data=countBy(allResults,c.key);const sorted=Object.entries(data).sort((a,b)=>b[1]-a[1]).slice(0,6);const cmax=Math.max(...sorted.map(x=>x[1]),1);return`<div class="chart-card"><div class="chart-title">${c.title}</div><div class="bar-chart">${sorted.map(([lbl,cnt])=>`<div class="bar-row"><span class="bar-label">${esc(lbl)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.round(cnt/cmax*100)}%;background:${c.color}"></div></div><span class="bar-count">${cnt}</span></div>`).join('')}</div></div>`;}).join('');}
function countBy(arr,key){const r={};arr.forEach(v=>{const k=v[key]||'Unknown';r[k]=(r[k]||0)+1;});return r;}

// SAVED SEARCHES
function toggleSaved(){const p=document.getElementById('savedPanel');p.classList.toggle('open');if(p.classList.contains('open'))renderSP();}
function switchTab(tab){activeTab=tab;document.getElementById('tabSaved').classList.toggle('active',tab==='saved');document.getElementById('tabHist').classList.toggle('active',tab==='history');renderSP();}
function renderSP(){const body=document.getElementById('spBody');if(activeTab==='saved'){if(!savedSearches.length){body.innerHTML='<div class="sp-empty">No saved searches yet.<br>Set filters and click Save.</div>';return;}body.innerHTML=savedSearches.map((s,i)=>`<div class="sp-item" onclick="loadSaved(${i})"><div class="sp-item-icon">💾</div><div class="sp-item-info"><div class="sp-item-name">${esc(s.name)}</div><div class="sp-item-meta">${s.filterCount} filter${s.filterCount!==1?'s':''} · ${s.fieldCount} fields · ${s.date}</div></div><div class="sp-acts"><button class="sp-abtn" onclick="event.stopPropagation();loadSaved(${i})" title="Load">▶</button><button class="sp-abtn del" onclick="event.stopPropagation();deleteSaved(${i})" title="Delete">🗑</button></div></div>`).join('');}else{if(!searchHistory.length){body.innerHTML='<div class="sp-empty">No search history yet.</div>';return;}body.innerHTML=searchHistory.slice(0,20).map((h,i)=>`<div class="hist-item" onclick="loadHistory(${i})"><div class="hist-icon">🕐</div><div class="hist-text">${esc(h.summary)}</div><div class="hist-meta">${h.results} results · ${h.time}</div><button class="hist-rm" onclick="event.stopPropagation();removeHistory(${i})">×</button></div>`).join('');}}
function saveCurrentSearch(){const activeF=AF.filter(f=>f.value&&f.value!=='');document.getElementById('saveSummary').textContent=`${activeF.length} active filter${activeF.length!==1?'s':''} · ${selIds.length} fields selected`;document.getElementById('saveNameInput').value='';document.getElementById('saveModal').classList.add('open');setTimeout(()=>document.getElementById('saveNameInput').focus(),100);}
function closeSM(){document.getElementById('saveModal').classList.remove('open');}
function confirmSave(){const name=document.getElementById('saveNameInput').value.trim();if(!name){document.getElementById('saveNameInput').style.borderColor='var(--red)';return;}const activeF=AF.filter(f=>f.value&&f.value!=='');const snapshot=AF.filter(f=>f.value).map(f=>({id:f.id,value:f.raw||f.value}));savedSearches.unshift({name,date:new Date().toLocaleDateString(),filterCount:activeF.length,fieldCount:selIds.length,filters:snapshot,fieldIds:[...selIds]});try{localStorage.setItem('si_saved',JSON.stringify(savedSearches));}catch(e){}updateSavedCount();closeSM();renderSP();toast(`✓ Saved "${name}"`,'success');}
function loadSaved(i){const s=savedSearches[i];AF.forEach(f=>{f.value='';f.raw='';});s.filters.forEach(({id,value})=>{const f=AF.find(x=>x.id===id);if(f){f.value=value;f.raw=value;}});selIds=[...s.fieldIds];pendIds=[...selIds];applyFilter();renderSelTags();updateCfgCount();updateActiveCount();renderFields();document.getElementById('savedPanel').classList.remove('open');toast(`✓ Loaded "${s.name}"`,'success');}
function deleteSaved(i){savedSearches.splice(i,1);try{localStorage.setItem('si_saved',JSON.stringify(savedSearches));}catch(e){}updateSavedCount();renderSP();}
function updateSavedCount(){document.getElementById('savedCount').textContent=`(${savedSearches.length})`;}
function addToHistory(summary,fc,rc){const filters=AF.filter(f=>f.value&&f.value!=='').map(f=>({id:f.id,value:f.raw||f.value}));searchHistory.unshift({summary,filters,fieldIds:[...selIds],results:rc,time:new Date().toLocaleTimeString()});if(searchHistory.length>30)searchHistory.pop();try{localStorage.setItem('si_hist',JSON.stringify(searchHistory));}catch(e){}}
function loadHistory(i){const h=searchHistory[i];if(!h)return;AF.forEach(f=>{f.value='';f.raw='';});if(h.filters&&h.filters.length){h.filters.forEach(({id,value})=>{const f=AF.find(x=>x.id===id);if(f){f.value=value;f.raw=value;}});}if(h.fieldIds&&h.fieldIds.length){selIds=[...h.fieldIds];pendIds=[...selIds];updateCfgCount();applyFilter();renderSelTags();}document.getElementById('savedPanel').classList.remove('open');toast(`✓ Restored search from history`,'success');}
function removeHistory(i){searchHistory.splice(i,1);renderSP();}

// CLEAR
function clearAll(){AF.forEach(f=>{f.value='';f.raw='';});document.getElementById('resultsPanel').classList.remove('open');document.getElementById('chartsPanel').classList.remove('open');document.getElementById('statsBar').classList.remove('visible');activePreset=null;renderPresets();renderFields();updateActiveCount();updateStats([]);toast('All filters cleared','info');}

// TOAST
function toast(msg,type='info'){const c=document.getElementById('toastCt');const t=document.createElement('div');t.className=`toast ${type}`;t.textContent=msg;c.appendChild(t);requestAnimationFrame(()=>{requestAnimationFrame(()=>t.classList.add('show'));});setTimeout(()=>{t.classList.remove('show');setTimeout(()=>t.remove(),400);},3000);}

function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

// ═══════════════════════════════════════════════════════════════════════════
// REAL API INTEGRATION
// ═══════════════════════════════════════════════════════════════════════════
// REAL API INTEGRATION — aligned to ShipInfo_API (ASP.NET + Dapper + SQL)
//
// Backend contract (from your Visual Studio code):
//   POST   /api/shipinfo/search
//   Body:  { SelectedColumns: string[], Filters: [{ Column, Operator, Value }] }
//   Table: shipinfo_final
//   Max columns: 25
//   Operators:   equals | contains | startswith | range | gte | lte
//
// The frontend label → SQL column name mapping is in colNameFor().
// Falls back to mock data automatically if the API is unreachable.
// ═══════════════════════════════════════════════════════════════════════════

// Your API base — controller is "shipinfo" → route = api/shipinfo
const API_BASE  = '/api/shipinfo';
let useRealApi  = true;

// ── Column name mapping ────────────────────────────────────────────────────
// Maps frontend field labels → exact SQL column names in shipinfo_final.
// Extend this as you discover column names from your database.
function colNameFor(f) {
  const MAP = {
    // Identity
    'Vessel Name':          'VesselName',
    'IMO Number':           'IMONumber',
    'MMSI Number':          'MMSINumber',
    'Call Sign':            'CallSign',
    'Flag State':           'FlagState',
    'Ship Type':            'ShipType',
    'Sub Type':             'SubType',
    'Gross Tonnage':        'GrossTonnage',
    'Net Tonnage':          'NetTonnage',
    'Deadweight (t)':       'Deadweight',
    'Year Built':           'YearBuilt',
    'Builder':              'Builder',
    'Shipyard Country':     'ShipyardCountry',
    'Port of Registry':     'PortOfRegistry',
    'Length Overall (m)':   'LengthOverall',
    'Breadth Moulded (m)':  'BreadthMoulded',
    'Depth Moulded (m)':    'DepthMoulded',
    'Draft Max (m)':        'DraftMax',
    'Draft Summer (m)':     'DraftSummer',
    'Displacement (t)':     'Displacement',
    // Technical
    'Main Engine Make':     'MainEngineMake',
    'Main Engine Model':    'MainEngineModel',
    'Engine Power (kW)':    'EnginePowerKW',
    'Engine RPM':           'EngineRPM',
    'Propulsion Type':      'PropulsionType',
    'Fuel Type Primary':    'FuelTypePrimary',
    'Fuel Type Secondary':  'FuelTypeSecondary',
    'Speed Service (kn)':   'SpeedService',
    'Speed Max (kn)':       'SpeedMax',
    'Speed Eco (kn)':       'SpeedEco',
    'Bow Thruster':         'BowThruster',
    'Stern Thruster':       'SternThruster',
    'Number of Propellers': 'NumberOfPropellers',
    'Propeller Type':       'PropellerType',
    'Generator Count':      'GeneratorCount',
    'Generator Power (kW)': 'GeneratorPowerKW',
    'Crane Capacity (t)':   'CraneCapacity',
    'Crane Count':          'CraneCount',
    'Hatch Count':          'HatchCount',
    'Hold Count':           'HoldCount',
    'Hold Volume (m³)':     'HoldVolume',
    'Ballast Capacity (t)': 'BallastCapacity',
    'Bunker HFO (t)':       'BunkerHFO',
    'Bunker MGO (t)':       'BunkerMGO',
    'Hull Form':            'HullForm',
    'Air Draft (m)':        'AirDraft',
    // Navigation
    'AIS Status':           'AISStatus',
    'Latitude':             'Latitude',
    'Longitude':            'Longitude',
    'Current Speed (kn)':   'CurrentSpeed',
    'Heading (°)':          'Heading',
    'Destination Port':     'DestinationPort',
    'ETA':                  'ETA',
    'Last Port':            'LastPort',
    'Next Port':            'NextPort',
    'Nav Status':           'NavStatus',
    'Draft Current (m)':    'DraftCurrent',
    'Voyage Number':        'VoyageNumber',
    'Trade Route':          'TradeRoute',
    'Piracy Risk Zone':     'PiracyRiskZone',
    // Classification
    'Class Society':        'ClassSociety',
    'Class Notation Full':  'ClassNotationFull',
    'Last Survey Date':     'LastSurveyDate',
    'Next Survey Date':     'NextSurveyDate',
    'Survey Status':        'SurveyStatus',
    'Survey Type Due':      'SurveyTypeDue',
    'Ice Class':            'IceClass',
    'Class Status':         'ClassStatus',
    'Drydock Last':         'DrydockLast',
    'Drydock Due':          'DrydockDue',
    'ISM Code Status':      'ISMCodeStatus',
    'ISPS Status':          'ISPSStatus',
    // Ownership
    'Registered Owner':     'RegisteredOwner',
    'Owner Country':        'OwnerCountry',
    'Owner Type':           'OwnerType',
    'Technical Manager':    'TechnicalManager',
    'Commercial Manager':   'CommercialManager',
    'ISM Manager':          'ISMManager',
    'Beneficial Owner':     'BeneficialOwner',
    'Operator Name':        'OperatorName',
    'Operator Country':     'OperatorCountry',
    'Fleet Name':           'FleetName',
    // Cargo
    'Cargo Type':           'CargoType',
    'Sub Cargo Type':       'SubCargoType',
    'TEU Capacity':         'TEUCapacity',
    'Liquid Capacity (m³)': 'LiquidCapacity',
    'Grain Capacity (m³)':  'GrainCapacity',
    'Bale Capacity (m³)':   'BaleCapacity',
    'Double Hull':          'DoubleHull',
    'Reefer Plugs':         'ReeferPlugs',
    'Tanker Product Type':  'TankerProductType',
    'Gas Type':             'GasType',
    'Last Cargo':           'LastCargo',
    // Port & Call
    'Home Port':            'HomePort',
    'Last Port of Call':    'LastPortOfCall',
    'Next Port of Call':    'NextPortOfCall',
    'Port State':           'PortState',
    'Terminal':             'Terminal',
    'Agent Name':           'AgentName',
    'Agent Port':           'AgentPort',
    'Loading Status':       'LoadingStatus',
    'Discharging Status':   'DischargingStatus',
    // Compliance
    'PSC Deficiencies':     'PSCDeficiencies',
    'PSC Detentions':       'PSCDetentions',
    'Sanctions Status':     'SanctionsStatus',
    'US OFAC':              'USOFAC',
    'EU Sanctions':         'EUSanctions',
    'Black List':           'BlackList',
    'Grey List':            'GreyList',
    'White List':           'WhiteList',
    'Ship Arrest':          'ShipArrest',
    'AML Check':            'AMLCheck',
    'BO Verified':          'BOVerified',
    // Environmental
    'EEDI Rating':          'EEDIRating',
    'EEXI Rating':          'EEXIRating',
    'CII Rating':           'CIIRating',
    'Carbon Intensity':     'CarbonIntensity',
    'SOx Scrubber':         'SOxScrubber',
    'NOx Tier':             'NOxTier',
    'Ballast Water System': 'BallastWaterSystem',
    'LNG Ready':            'LNGReady',
    'Shore Power Ready':    'ShorePowerReady',
    'Hull Coating':         'HullCoating',
    // Crew
    'Crew Count':           'CrewCount',
    'Officers Count':       'OfficersCount',
    'Ratings Count':        'RatingsCount',
    'Crew Nationality':     'CrewNationality',
    'Manning Agency':       'ManningAgency',
    'Master Name':          'MasterName',
  };
  // Exact match first, then PascalCase fallback
  return MAP[f.label]
    || f.label.replace(/[^a-zA-Z0-9]+(.?)/g, (_, c) => c.toUpperCase())
              .replace(/^(.)/, c => c.toUpperCase());
}

// ── Operator mapping ───────────────────────────────────────────────────────
// Frontend parseOp() types → SQL operators your backend understands
function toBackendOperator(opType) {
  const MAP = {
    'none':      'equals',
    'contains':  'contains',
    'starts':    'startswith',
    'not':       'notequals',
    'gte':       'gte',
    'lte':       'lte',
    'gt':        'gte',      // approximate — backend has gte/lte only
    'lt':        'lte',
    'range':     'range',
    'or':        'contains', // OR handled client-side; send first value
    'is_empty':  'equals',
    'not_empty': 'notequals',
  };
  return MAP[opType] || 'equals';
}

// ── Build ShipInfoSearchRequest ────────────────────────────────────────────
function buildShipInfoRequest(activeFilters, colFields) {
  // SelectedColumns: the SQL column names the user has picked (max 25)
  const selectedColumns = colFields.map(f => colNameFor(f));

  // Filters: [{Column, Operator, Value}]
  const filters = [];
  for (const f of activeFilters) {
    if (!f.value && f.value !== 0) continue;
    const raw    = f.raw || f.value || '';
    const op     = parseOp(raw);
    const column = colNameFor(f);

    if (op.t === 'range') {
      // range: send as two separate filters (gte + lte)
      filters.push({ Column: column, Operator: 'gte', Value: op.lo });
      filters.push({ Column: column, Operator: 'lte', Value: op.hi });
    } else if (op.t === 'or') {
      // OR: send each value as a separate contains filter
      for (const v of op.vs)
        filters.push({ Column: column, Operator: 'contains', Value: v });
    } else if (op.t === 'is_empty') {
      filters.push({ Column: column, Operator: 'equals', Value: '' });
    } else if (op.t === 'not_empty') {
      filters.push({ Column: column, Operator: 'notequals', Value: '' });
    } else if (op.t === 'not') {
      filters.push({ Column: column, Operator: 'notequals', Value: op.v });
    } else if (op.t === 'starts') {
      filters.push({ Column: column, Operator: 'startswith', Value: op.v });
    } else if (op.t === 'none') {
      // plain value — use contains for text, equals for select/number
      const operator = (f.type === 'select' || f.type === 'number') ? 'equals' : 'contains';
      filters.push({ Column: column, Operator: operator, Value: f.value });
    } else {
      filters.push({ Column: column, Operator: toBackendOperator(op.t), Value: op.v ?? f.value });
    }
  }

  return { SelectedColumns: selectedColumns, Filters: filters };
}

// ── Map a SQL result row → frontend result object ──────────────────────────
// Your backend returns dynamic objects from shipinfo_final.
// Column names match what we sent in SelectedColumns (PascalCase).
function mapSqlRow(row, idx, colFields) {
  // Helper: get value by column name (case-insensitive)
  function get(col) {
    if (row[col] !== undefined) return row[col];
    // Try case-insensitive
    const key = Object.keys(row).find(k => k.toLowerCase() === col.toLowerCase());
    return key ? row[key] : '—';
  }

  const name   = get('VesselName')  || get('Vessel Name') || '—';
  const imo    = get('IMONumber')   || get('IMO Number')  || '—';
  const mmsi   = get('MMSINumber')  || get('MMSI Number') || '—';
  const flag   = get('FlagState')   || get('Flag State')  || '—';
  const type   = get('ShipType')    || get('Ship Type')   || '—';
  const yr     = parseInt(get('YearBuilt') || get('Year Built') || 0);
  const grt    = parseFloat(get('GrossTonnage') || get('Gross Tonnage') || 0);
  const aisRaw = get('AISStatus')   || get('AIS Status')  || '';
  const cii    = get('CIIRating')   || get('CII Rating')  || '—';
  const sanc   = get('SanctionsStatus') || get('Sanctions Status') || 'Clear';

  const stcMap = {
    'under way':   'st-transit',
    'moored':      'st-anchor',
    'at anchor':   'st-anchor',
    'not under':   'st-active',
  };
  const aisL = aisRaw.toLowerCase();
  const stc  = Object.entries(stcMap).find(([k]) => aisL.includes(k))?.[1] ?? 'st-active';

  const base = {
    _i: idx, name, imo, mmsi, flag, type, yr, grt,
    status: aisRaw || 'Unknown', stc, cs: get('CallSign') || '—',
    cii, _sanc: sanc,
    _decade: yr ? `${Math.floor(yr / 10) * 10}s` : '—',
  };

  // Populate each selected column field
  for (const f of colFields) {
    const col = colNameFor(f);
    base[f.id] = get(col);
  }
  return base;
}

// ── Live runSearch — replaces mock ─────────────────────────────────────────
const _mockRunSearch = runSearch;

async function runSearch() {
  const activeF   = AF.filter(f => f.value && f.value !== '');
  const colFields = selIds.length > 0
    ? selIds.map(id => AF.find(f => f.id === id)).filter(Boolean)
    : AF.slice(0, 8);

  if (!useRealApi) { _mockRunSearch(); return; }

  // Show loading state
  const rpCount = document.getElementById('rpCount');
  rpCount.textContent = 'Searching…';
  document.getElementById('resultsPanel').classList.add('open');

  try {
    const body     = buildShipInfoRequest(activeF, colFields);
    const t0       = performance.now();
    const res      = await fetch(`${API_BASE}/search`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => res.statusText);
      throw new Error(`${res.status}: ${errText}`);
    }

    // Your API returns the rows directly as a JSON array
    const data    = await res.json();
    const rows    = Array.isArray(data) ? data : (data.results || data.items || data.data || []);
    const elapsed = Math.round(performance.now() - t0);

    allResults = rows.map((row, i) => mapSqlRow(row, i, colFields));

    addToHistory(
      activeF.map(f => `${f.label}: ${f.value}`).join(', ') || '(all vessels)',
      activeF.length, allResults.length
    );
    updateStats(allResults);
    hiddenCols = new Set(); sortCol = null; resPage = 1;

    rpCount.textContent = `${allResults.length.toLocaleString()} vessel${allResults.length !== 1 ? 's' : ''} found`;
    document.getElementById('rpCI').textContent =
      `${colFields.length} col${colFields.length !== 1 ? 's' : ''} · ${elapsed}ms`;

    buildColToggles(colFields);
    document.getElementById('rpFI').value = '';
    renderRT();
    if (chartsOpen) renderCharts();
    toast(`🔍 ${allResults.length.toLocaleString()} vessel${allResults.length !== 1 ? 's' : ''} found`, 'info');

  } catch (err) {
    console.warn('[ShipInfo] API error, falling back to mock:', err.message);
    useRealApi = false;
    document.getElementById('resultsPanel').classList.remove('open');
    toast('⚠ API offline — showing demo data', 'info');
    _mockRunSearch();
  }
}







// ── Exported singleton for React components ─────────────────────────────────
export const searchEngine = {
  init() {
    if (typeof buildChips === 'function') buildChips();
    if (typeof renderPresets === 'function') renderPresets();
    pendIds = AF.slice(0, MAX).map(f => f.id);
    selIds  = [...pendIds];
    applyFieldSel(true);
    try { const s = localStorage.getItem('si_saved'); if (s) savedSearches = JSON.parse(s); } catch(e) {}
    try { const h = localStorage.getItem('si_hist');  if (h) searchHistory = JSON.parse(h); } catch(e) {}
    updateSavedCount();
    updateStats([]);
    document.addEventListener('click', e => {
      if (openTT !== null && !e.target.closest('.field-card')) closeAllTT();
      const sp = document.getElementById('savedPanel');
      const sb = document.getElementById('savedBtn');
      if (sp && sb && !e.target.closest('.saved-panel') && !e.target.closest('#savedBtn'))
        sp.classList.remove('open');
    });
    setupKb();
  },
  runSearch, toggleConfigurator, toggleSaved, toggleCharts,
  clearAll, openSC, closeSC, closeResults, closeDetail,
  exportCSV, selTopN, clearCfgSel, applyFieldSel,
  renderCfgList, clearFS, onFS, closeSM, confirmSave,
  saveCurrentSearch, switchTab, renderRT,
  getActiveCount: () => AF.filter(f => f.value && f.value !== '').length,
  getSavedCount:  () => savedSearches.length,
  getCfgSelCount: () => `${selIds.length}/${MAX}`,
  hasActiveFilters: () => AF.some(f => f.value && f.value !== ''),
};
