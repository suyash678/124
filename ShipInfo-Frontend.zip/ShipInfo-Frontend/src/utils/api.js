/**
 * api.js — All HTTP calls to the ShipInfo backend.
 *
 * Backend: ShipInfo_API (ASP.NET Core + Dapper + SQL Server)
 * Controller route: /api/shipinfo
 * Table: shipinfo_final
 *
 * In development, Vite proxies /api → http://localhost:5000 (see vite.config.js).
 * In production, set VITE_API_BASE in your .env file.
 */

const API_BASE = import.meta.env.VITE_API_BASE ?? '/api/shipinfo';

// ── Generic fetch helper ──────────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  if (!res.ok) {
    const body = await res.text().catch(() => res.statusText);
    throw new Error(`API ${res.status}: ${body}`);
  }
  return res.json();
}

// ── Search ────────────────────────────────────────────────────────────────────
/**
 * POST /api/shipinfo/search
 *
 * @param {string[]}  selectedColumns  - SQL column names to retrieve (max 25)
 * @param {Array}     filters          - [{Column, Operator, Value}]
 *   Operators: equals | contains | startswith | range | gte | lte
 *
 * @returns {Promise<any[]>}  Array of dynamic row objects from shipinfo_final
 *
 * Example:
 *   searchVessels(
 *     ['VesselName','IMONumber','FlagState','GrossTonnage'],
 *     [{ Column:'FlagState', Operator:'equals', Value:'Panama' },
 *      { Column:'GrossTonnage', Operator:'gte', Value:50000 }]
 *   )
 */
export async function searchVessels(selectedColumns, filters = []) {
  return apiFetch('/search', {
    method: 'POST',
    body: JSON.stringify({
      SelectedColumns: selectedColumns,
      Filters: filters,
    }),
  });
}

// ── Support ───────────────────────────────────────────────────────────────────
/**
 * POST /api/shipinfo/support  (or your support endpoint)
 * Submits a support request to the data team.
 */
export async function submitSupportRequest(payload) {
  // Adjust the path if your support endpoint is on a different controller
  return apiFetch('/support', {
    method: 'POST',
    body: JSON.stringify(payload),
  }).catch(() => {
    // Offline fallback — generate a local reference number
    return {
      refNumber: 'REF-' + Date.now().toString(36).toUpperCase().slice(-8),
      message: 'Request queued — will be sent when API is available.',
    };
  });
}
