import { useState, useEffect } from 'react';
import Nav from './components/Nav/Nav.jsx';
import HeroView from './components/Hero/HeroView.jsx';
import SearchView from './components/Search/SearchView.jsx';
import SupportView from './components/Support/SupportView.jsx';
import { useSearch } from './hooks/useSearch.js';

export default function App() {
  const [view, setView] = useState('hero');
  const [user, setUser] = useState({ displayName: 'User Name', email: '', photo: null });
  const searchState     = useSearch();

  // SSO: your MSAL/OAuth callback calls window.setUserFromSSO(profile) after login
  useEffect(() => {
    window.setUserFromSSO = (profile) => { if (profile) setUser(profile); };
    return () => { delete window.setUserFromSSO; };
  }, []);

  return (
    <>
      <Nav view={view} setView={setView} user={user} searchState={searchState} />
      {view === 'hero'    && <HeroView    setView={setView} />}
      {view === 'search'  && <SearchView  user={user} />}
      {view === 'support' && <SupportView user={user} />}
    </>
  );
}
