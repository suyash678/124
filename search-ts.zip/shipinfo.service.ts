import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ShipInfoSearchRequest, VesselRow } from '../models/shipinfo.models';

@Injectable({ providedIn: 'root' })
export class ShipInfoService {
  private readonly base = environment.apiBase;

  constructor(private http: HttpClient) {}

  /**
   * POST /api/shipinfo/search
   * Body: { SelectedColumns: string[], Filters: [{Column, Operator, Value}] }
   * Returns: plain array of row objects from shipinfo_final
   */
  search(request: ShipInfoSearchRequest): Observable<VesselRow[]> {
    return this.http
      .post<VesselRow[]>(`${this.base}/search`, request)
      .pipe(catchError(this.handleError));
  }

  /**
   * GET /api/shipinfo/columns
   * Returns: string[] of column names from shipinfo_final
   */
  getColumns(): Observable<string[]> {
    return this.http
      .get<string[]>(`${this.base}/columns`)
      .pipe(catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg = err.error?.message ?? err.message ?? 'Unknown API error';
    return throwError(() => new Error(`${err.status}: ${msg}`));
  }
}
